const fs = require('fs');
let html = fs.readFileSync('localSetup.html', 'utf8');

// Fix the missing </div>
html = html.replace(
  '<label class="toggle-switch">\r\n            <input type="checkbox" id="defaultAi" checked>\r\n            <span class="toggle-slider"></span>\r\n          </label>\r\n        <div class="setting-row">',
  '<label class="toggle-switch">\r\n            <input type="checkbox" id="defaultAi" checked>\r\n            <span class="toggle-slider"></span>\r\n          </label>\r\n        </div>\r\n        <div class="setting-row">'
);
html = html.replace(
  '<label class="toggle-switch">\n            <input type="checkbox" id="defaultAi" checked>\n            <span class="toggle-slider"></span>\n          </label>\n        <div class="setting-row">',
  '<label class="toggle-switch">\n            <input type="checkbox" id="defaultAi" checked>\n            <span class="toggle-slider"></span>\n          </label>\n        </div>\n        <div class="setting-row">'
);

// New CSS
const newCss = `
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap');
    
    :root {
      --bg: #09090e;
      --bg-glass: rgba(18, 18, 28, 0.6);
      --bg-glass-hover: rgba(25, 25, 38, 0.8);
      --accent: #8b5cf6;
      --accent-hover: #a78bfa;
      --accent-gradient: linear-gradient(135deg, #a78bfa, #c4b5fd, #8b5cf6);
      --green: #10b981;
      --green-glow: rgba(16, 185, 129, 0.4);
      --red: #ef4444;
      --orange: #f59e0b;
      --text: #f8fafc;
      --text2: #94a3b8;
      --border: rgba(255, 255, 255, 0.08);
      --border-highlight: rgba(139, 92, 246, 0.3);
      --radius: 20px;
      --shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);
    }

    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      font-family: 'Inter', sans-serif;
      background: var(--bg);
      color: var(--text);
      min-height: 100vh;
      padding: 50px 20px;
      line-height: 1.6;
      position: relative;
      overflow-x: hidden;
    }

    /* Ambient Background Blobs */
    .blob {
      position: absolute;
      filter: blur(100px);
      z-index: -1;
      opacity: 0.5;
      animation: float 10s ease-in-out infinite alternate;
    }
    .blob-1 { top: -100px; left: -100px; width: 400px; height: 400px; background: rgba(139, 92, 246, 0.3); }
    .blob-2 { bottom: -150px; right: -50px; width: 500px; height: 500px; background: rgba(16, 185, 129, 0.2); animation-delay: -5s; }
    .blob-3 { top: 40%; left: 30%; width: 300px; height: 300px; background: rgba(245, 158, 11, 0.15); animation-duration: 15s; }

    @keyframes float {
      0% { transform: translate(0, 0) scale(1); }
      100% { transform: translate(30px, 50px) scale(1.1); }
    }

    .container {
      max-width: 960px;
      margin: 0 auto;
      position: relative;
      z-index: 1;
    }

    .header {
      text-align: center;
      margin-bottom: 50px;
      animation: fadeInDown 0.8s ease-out;
    }

    @keyframes fadeInDown {
      from { opacity: 0; transform: translateY(-20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .header h1 {
      font-family: 'Outfit', sans-serif;
      font-size: 42px;
      font-weight: 800;
      background: var(--accent-gradient);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 12px;
      letter-spacing: -1px;
      filter: drop-shadow(0 2px 10px rgba(139, 92, 246, 0.3));
    }

    .header p {
      color: var(--text2);
      font-size: 16px;
      max-width: 600px;
      margin: 0 auto;
    }

    .grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 24px;
    }

    @media (max-width: 768px) { .grid { grid-template-columns: 1fr; } }

    /* Glassmorphism Cards */
    .card {
      background: var(--bg-glass);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border: 1px solid var(--border);
      border-top: 1px solid rgba(255,255,255,0.15);
      border-left: 1px solid rgba(255,255,255,0.1);
      border-radius: var(--radius);
      padding: 32px;
      margin-bottom: 24px;
      box-shadow: var(--shadow);
      position: relative;
      overflow: hidden;
      transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      animation: fadeInUp 0.6s ease-out backwards;
    }
    
    .card:nth-child(1) { animation-delay: 0.1s; }
    .card:nth-child(2) { animation-delay: 0.2s; }
    .card:nth-child(3) { animation-delay: 0.3s; }

    @keyframes fadeInUp {
      from { opacity: 0; transform: translateY(30px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .card:hover {
      transform: translateY(-5px);
      border-color: var(--border-highlight);
      box-shadow: 0 15px 45px rgba(0,0,0,0.4), 0 0 20px rgba(139, 92, 246, 0.15);
      background: var(--bg-glass-hover);
    }

    .card-title {
      display: flex;
      align-items: center;
      gap: 12px;
      font-family: 'Outfit', sans-serif;
      font-size: 22px;
      font-weight: 700;
      margin-bottom: 24px;
      padding-bottom: 16px;
      border-bottom: 1px solid var(--border);
      color: #fff;
    }

    /* Premium Subscription Card */
    .card-premium {
      background: linear-gradient(135deg, rgba(26, 26, 46, 0.8), rgba(22, 33, 62, 0.9));
      border: 1px solid rgba(139, 92, 246, 0.4);
      grid-column: span 2;
      box-shadow: 0 10px 40px rgba(0,0,0,0.5), inset 0 0 40px rgba(139, 92, 246, 0.1);
    }
    
    .card-premium::before {
      content: '';
      position: absolute;
      top: 0; left: 0; right: 0; height: 2px;
      background: var(--accent-gradient);
    }

    @media (max-width: 768px) { .card-premium { grid-column: span 1; } }

    .premium-badge {
      position: absolute;
      top: 20px;
      right: -35px;
      background: linear-gradient(90deg, #f59e0b, #fbbf24);
      color: #000;
      font-weight: 800;
      font-size: 11px;
      padding: 6px 45px;
      transform: rotate(45deg);
      text-transform: uppercase;
      letter-spacing: 1px;
      box-shadow: 0 4px 15px rgba(245, 158, 11, 0.4);
    }

    .subscription-content { display: flex; gap: 40px; align-items: center; }
    @media (max-width: 768px) { .subscription-content { flex-direction: column; align-items: stretch; gap: 24px; } }

    .sub-info-panel { flex: 1.2; }
    .sub-action-panel { flex: 0.8; text-align: center; background: rgba(0,0,0,0.2); padding: 24px; border-radius: 16px; border: 1px solid var(--border); }

    .price-tag { font-family: 'Outfit', sans-serif; font-size: 36px; font-weight: 800; color: #fff; margin-bottom: 4px; text-shadow: 0 2px 10px rgba(255,255,255,0.1); }
    .price-desc { color: var(--text2); font-size: 14px; margin-bottom: 20px; }

    /* Forms and Inputs */
    .provider-tabs {
      display: flex;
      gap: 6px;
      margin-bottom: 24px;
      background: rgba(0,0,0,0.3);
      padding: 6px;
      border-radius: 14px;
      border: 1px solid var(--border);
    }

    .provider-tab {
      flex: 1;
      padding: 10px;
      text-align: center;
      cursor: pointer;
      background: transparent;
      border-radius: 10px;
      font-weight: 600;
      font-size: 14px;
      transition: all 0.3s ease;
      border: none;
      color: var(--text2);
      font-family: 'Inter', sans-serif;
    }

    .provider-tab:hover { color: #fff; background: rgba(255,255,255,0.05); }
    .provider-tab.active { background: var(--accent); color: #fff; box-shadow: 0 4px 15px rgba(139, 92, 246, 0.4); }

    .keys-textarea {
      width: 100%;
      height: 100px;
      background: rgba(0,0,0,0.2);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 16px;
      color: #fff;
      font-family: monospace;
      font-size: 13px;
      resize: vertical;
      margin-bottom: 12px;
      transition: all 0.3s;
    }

    .keys-textarea:focus { outline: none; border-color: var(--accent); box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.2); background: rgba(0,0,0,0.3); }

    .btn {
      padding: 12px 24px;
      border-radius: 12px;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      transition: all 0.3s ease;
      border: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      font-family: 'Inter', sans-serif;
    }

    .btn:active { transform: scale(0.97); }
    .btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none !important; }

    .btn-primary { background: var(--accent); color: #fff; box-shadow: 0 4px 15px rgba(139, 92, 246, 0.3); }
    .btn-primary:hover:not(:disabled) { background: var(--accent-hover); box-shadow: 0 6px 20px rgba(139, 92, 246, 0.4); }

    .btn-green { background: linear-gradient(135deg, #10b981, #059669); color: #fff; box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3); font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
    .btn-green:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 6px 25px rgba(16, 185, 129, 0.5); }

    .btn-danger { background: rgba(239, 68, 68, 0.1); color: var(--red); border: 1px solid rgba(239, 68, 68, 0.3); }
    .btn-danger:hover:not(:disabled) { background: var(--red); color: #fff; }

    .btn-outline { background: transparent; color: var(--text); border: 1px solid var(--border); }
    .btn-outline:hover:not(:disabled) { background: rgba(255,255,255,0.05); border-color: rgba(255,255,255,0.2); }

    /* Settings Rows */
    .setting-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      margin-bottom: 12px;
      padding: 12px;
      border-radius: 12px;
      background: rgba(255,255,255,0.02);
      border: 1px solid transparent;
      transition: all 0.2s;
    }
    
    .setting-row:hover { background: rgba(255,255,255,0.04); border-color: rgba(255,255,255,0.05); }

    .setting-row label:not(.toggle-switch) { flex: 1; font-size: 14px; font-weight: 500; color: var(--text); }

    .setting-row input[type="number"],
    .setting-row select,
    .setting-row input[type="text"] {
      width: 160px;
      background: rgba(0,0,0,0.3);
      border: 1px solid var(--border);
      border-radius: 10px;
      color: var(--text);
      padding: 10px 14px;
      font-size: 14px;
      transition: all 0.3s;
      font-family: 'Inter', sans-serif;
    }

    .setting-row input:focus, .setting-row select:focus { outline: none; border-color: var(--accent); box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.2); }
    .setting-desc { font-size: 13px; color: var(--text2); margin: -4px 0 24px 12px; line-height: 1.5; }

    /* Toggle Switch */
    .toggle-switch { position: relative; display: inline-block; width: 46px; height: 26px; }
    .toggle-switch input { opacity: 0; width: 0; height: 0; }
    .toggle-slider { position: absolute; cursor: pointer; inset: 0; background: rgba(255,255,255,0.1); border-radius: 26px; transition: 0.4s cubic-bezier(0.4, 0, 0.2, 1); border: 1px solid var(--border); }
    .toggle-slider:before { content: ''; position: absolute; height: 18px; width: 18px; left: 3px; bottom: 3px; background: #fff; border-radius: 50%; transition: 0.4s cubic-bezier(0.4, 0, 0.2, 1); box-shadow: 0 2px 5px rgba(0,0,0,0.3); }
    .toggle-switch input:checked + .toggle-slider { background: var(--accent); border-color: var(--accent); box-shadow: inset 0 0 10px rgba(0,0,0,0.2); }
    .toggle-switch input:checked + .toggle-slider:before { transform: translateX(20px); }

    /* Key List */
    .key-item { display: flex; align-items: center; gap: 12px; padding: 14px 16px; background: rgba(0,0,0,0.2); border-radius: 12px; margin-bottom: 10px; border: 1px solid var(--border); transition: all 0.3s; }
    .key-item:hover { border-color: rgba(255,255,255,0.1); }
    .key-item.valid { border-color: rgba(16, 185, 129, 0.4); background: rgba(16, 185, 129, 0.05); }
    .key-text { flex: 1; font-family: monospace; font-size: 13px; color: var(--text2); letter-spacing: 0.5px; }
    .key-status { font-size: 11px; padding: 4px 12px; border-radius: 20px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
    .status-valid { background: rgba(16, 185, 129, 0.15); color: var(--green); border: 1px solid rgba(16, 185, 129, 0.3); }

    /* Utilities */
    .divider { height: 1px; background: linear-gradient(90deg, transparent, var(--border), transparent); margin: 24px 0; }
    
    .status-bar {
      background: rgba(0,0,0,0.2);
      border-radius: 12px;
      padding: 16px;
      font-size: 14px;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 12px;
      margin-top: 16px;
      border: 1px solid var(--border);
      animation: slideIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    @keyframes slideIn { from { transform: translateX(-15px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    .status-bar.success { border-color: rgba(16, 185, 129, 0.4); color: var(--green); background: rgba(16, 185, 129, 0.05); }
    .status-bar.error { border-color: rgba(239, 68, 68, 0.4); color: var(--red); background: rgba(239, 68, 68, 0.05); }

    .spinner { width: 18px; height: 18px; border: 3px solid rgba(255, 255, 255, 0.2); border-top-color: white; border-radius: 50%; animation: spin 0.8s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }

    .pricing-features { list-style: none; margin: 15px 0; }
    .pricing-features li { font-size: 14px; color: var(--text); margin-bottom: 10px; display: flex; align-items: center; gap: 10px; }
    .pricing-features li:before { content: '✨'; font-size: 14px; }

    .sub-badge-active { background: rgba(16, 185, 129, 0.15); color: var(--green); border: 1px solid rgba(16, 185, 129, 0.4); padding: 4px 12px; border-radius: 20px; font-weight: 700; font-size: 12px; }
    .sub-badge-expired { background: rgba(239, 68, 68, 0.15); color: var(--red); border: 1px solid rgba(239, 68, 68, 0.4); padding: 4px 12px; border-radius: 20px; font-weight: 700; font-size: 12px; }

    /* Modal Styles */
    .modal-overlay { position: fixed; inset: 0; background: rgba(0, 0, 0, 0.7); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); display: none; align-items: center; justify-content: center; z-index: 1000; padding: 20px; }
    .modal { background: rgba(20, 20, 30, 0.95); border: 1px solid var(--border-highlight); border-radius: 24px; padding: 40px; max-width: 450px; width: 100%; box-shadow: 0 20px 60px rgba(0,0,0,0.6), inset 0 0 30px rgba(139, 92, 246, 0.1); text-align: center; animation: modalFadeIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
    @keyframes modalFadeIn { from { transform: scale(0.9) translateY(20px); opacity: 0; } to { transform: scale(1) translateY(0); opacity: 1; } }
    .modal-icon { font-size: 54px; margin-bottom: 24px; filter: drop-shadow(0 4px 10px rgba(0,0,0,0.3)); }
    .modal h2 { margin-bottom: 12px; color: #fff; font-family: 'Outfit', sans-serif; font-size: 28px; }
    .modal p { color: var(--text2); font-size: 15px; margin-bottom: 30px; line-height: 1.6; }
    .email-box { background: rgba(0,0,0,0.4); border: 1px solid var(--accent); padding: 16px 20px; border-radius: 16px; display: flex; align-items: center; justify-content: space-between; margin-bottom: 30px; }
    .email-box span { font-family: monospace; font-size: 18px; color: var(--text); font-weight: 700; letter-spacing: 0.5px; }
    .copy-btn-small { background: var(--accent); color: white; border: none; padding: 8px 16px; border-radius: 10px; font-size: 13px; font-weight: 600; cursor: pointer; transition: 0.3s; }
    .copy-btn-small:hover { background: var(--accent-hover); box-shadow: 0 4px 15px rgba(139, 92, 246, 0.4); }
    .modal-btns { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
`;

// Extract everything from <style> to </style>
const styleRegex = /<style>[\s\S]*?<\/style>/;
if (styleRegex.test(html)) {
  html = html.replace(styleRegex, '<style>\n' + newCss + '\n</style>');
}

// Add the background blobs
const bodyTagRegex = /<body>/;
if (bodyTagRegex.test(html) && !html.includes('<div class="blob blob-1"></div>')) {
  html = html.replace(bodyTagRegex, '<body>\n  <div class="blob blob-1"></div>\n  <div class="blob blob-2"></div>\n  <div class="blob blob-3"></div>');
}

fs.writeFileSync('localSetup.html', html);
console.log('Successfully redesigned localSetup.html!');
