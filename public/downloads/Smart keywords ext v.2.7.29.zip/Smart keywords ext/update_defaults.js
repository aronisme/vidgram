const fs = require('fs');
const files = ['localSetup.js', 'localMode.js', 'content/content.js', 'background.js'];

files.forEach(file => {
  if (fs.existsSync(file)) {
    let code = fs.readFileSync(file, 'utf8');
    
    // Replace maxKeywords defaults
    code = code.replace(/maxKeywords\s*=\s*49/g, 'maxKeywords = 35');
    code = code.replace(/maxKeywords\s*\|\|\s*49/g, 'maxKeywords || 35');
    code = code.replace(/maxKeywords\s*\|\|\s*50/g, 'maxKeywords || 35');
    code = code.replace(/maxKeywords:\s*49/g, 'maxKeywords: 35');
    code = code.replace(/value\s*=\s*49;/g, 'value = 35;');
    
    // Replace maxTitleLength defaults
    code = code.replace(/maxTitleLength\s*\|\|\s*200/g, 'maxTitleLength || 120');
    code = code.replace(/maxTitleLength:\s*200/g, 'maxTitleLength: 120');
    code = code.replace(/value\s*=\s*200;/g, 'value = 120;');
    
    fs.writeFileSync(file, code);
    console.log('Updated ' + file);
  }
});
