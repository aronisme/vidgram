import sys

with open('localSetup.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Remove the old setting row for uiLanguage
old_ui_language_html = '''        <div class="setting-row">
          <label data-i18n="ui_language">Bahasa UI / UI Language</label>
          <select id="uiLanguage">
            <option value="id">Indonesia</option>
            <option value="en">English</option>
          </select>
        </div>\n\n'''
content = content.replace(old_ui_language_html, '')

# 2. Inject CSS for lang-switcher
css_to_inject = '''
    .lang-switcher { position: absolute; top: 20px; right: 20px; z-index: 100; animation: fadeInDown 0.8s ease-out; }
    .lang-switcher select {
      background: var(--bg-glass); backdrop-filter: blur(10px); border: 1px solid var(--border);
      color: var(--text); padding: 8px 16px; border-radius: 20px; font-family: 'Outfit', sans-serif;
      font-size: 14px; font-weight: 600; cursor: pointer; outline: none; transition: all 0.3s ease;
      appearance: none; -webkit-appearance: none; padding-right: 32px;
      background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
      background-repeat: no-repeat; background-position: right 10px center; background-size: 14px;
    }
    .lang-switcher select:hover { border-color: var(--accent); box-shadow: 0 0 15px rgba(139, 92, 246, 0.2); }
    .lang-switcher select option { background-color: #12121c; color: #fff; }
'''
if '</style>' in content and '.lang-switcher' not in content:
    content = content.replace('</style>', css_to_inject + '</style>')

# 3. Inject the HTML for lang-switcher right after <body>
html_to_inject = '''  <div class="lang-switcher">
    <select id="uiLanguage" title="UI Language">
      <option value="id">🇮🇩 ID</option>
      <option value="en">🇬🇧 EN</option>
    </select>
  </div>
'''
if '<div class="lang-switcher">' not in content:
    content = content.replace('<body>', '<body>\n' + html_to_inject)

with open('localSetup.html', 'w', encoding='utf-8') as f:
    f.write(content)

print('Updated localSetup.html')
