import sys

with open('localSetup.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Make replacements
replacements = [
    ('<title>Pengaturan Smart Keywords - Sewa APIKey AI</title>', '<title data-i18n="ui_page_title">Pengaturan Smart Keywords - Sewa APIKey AI</title>'),
    ('<h1>🚀 Smart Keywords Pro</h1>', '<h1 data-i18n="ui_header_title">🚀 Smart Keywords Pro</h1>'),
    ('<p>Optimalkan metadata Adobe Stock Anda dengan kecerdasan AI tingkat tinggi. Pilih antara menggunakan kunci API\n        sendiri atau layanan sewa praktis.</p>', '<p data-i18n="ui_header_desc">Optimalkan metadata Adobe Stock Anda dengan kecerdasan AI tingkat tinggi. Pilih antara menggunakan kunci API\n        sendiri atau layanan sewa praktis.</p>'),
    ('<div class="premium-badge">Terpopuler</div>', '<div class="premium-badge" data-i18n="ui_premium_badge">Terpopuler</div>'),
    ('<div class="card-title">\n        <span class="icon">💎</span> Sewa APIKey AI (Rekomendasi)\n      </div>', '<div class="card-title">\n        <span class="icon">💎</span> <span data-i18n="ui_rent_api_title">Sewa APIKey AI (Rekomendasi)</span>\n      </div>'),
    ('<p style="margin-bottom: 12px; font-weight: 600;">Kenapa Sewa APIKey AI?</p>', '<p style="margin-bottom: 12px; font-weight: 600;" data-i18n="ui_why_rent">Kenapa Sewa APIKey AI?</p>'),
    ('<li>Akses Gemini 2.5, Llama 4 & Mistral Instan</li>', '<li data-i18n="ui_rent_feat1">Akses Gemini 2.5, Llama 4 & Mistral Instan</li>'),
    ('<li>Tidak perlu kartu kredit/billing sendiri</li>', '<li data-i18n="ui_rent_feat2">Tidak perlu kartu kredit/billing sendiri</li>'),
    ('<li>Kuota Unlimited & Kecepatan Tinggi</li>', '<li data-i18n="ui_rent_feat3">Kuota Unlimited & Kecepatan Tinggi</li>'),
    ('<li>Setup otomatis sekali klik</li>', '<li data-i18n="ui_rent_feat4">Setup otomatis sekali klik</li>'),
    ('<li>Boleh 2 Perangkat/Browser per Akun</li>', '<li data-i18n="ui_rent_feat5">Boleh 2 Perangkat/Browser per Akun</li>'),
    ('<p style="font-size: 13px; color: var(--orange); font-weight: 700; margin-top: 10px;">\n            ✨ Jangan pusing lagi dengan limit kuota AI!\n          </p>', '<p style="font-size: 13px; color: var(--orange); font-weight: 700; margin-top: 10px;" data-i18n="ui_rent_highlight">\n            ✨ Jangan pusing lagi dengan limit kuota AI!\n          </p>'),
    ('<span style="font-size: 13px; color: var(--text2);">Akun:</span>', '<span style="font-size: 13px; color: var(--text2);" data-i18n="ui_account">Akun:</span>'),
    ('<span style="font-size: 13px; color: var(--text2);">Status Langganan:</span>', '<span style="font-size: 13px; color: var(--text2);" data-i18n="ui_sub_status">Status Langganan:</span>'),
    ('<span id="subStatusBadge" class="sub-badge-active">Mengecek...</span>', '<span id="subStatusBadge" class="sub-badge-active" data-i18n="ui_checking">Mengecek...</span>'),
    ('<span style="font-size: 13px; color: var(--text2);">Berakhir Pada:</span>', '<span style="font-size: 13px; color: var(--text2);" data-i18n="ui_ends_on">Berakhir Pada:</span>'),
    ('<div id="subExpiredNotice" style="display: none; margin-top: 15px; padding: 12px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 10px; color: #fca5a5; font-size: 12px; text-align: center; line-height: 1.5;">\n               ⚠️ Paket sewa API Anda telah berakhir. <br>Silakan perpanjang untuk terus menggunakan AI tanpa batas!<br><br>\n               💡 <i>Atau jika Anda ingin menggunakan API Anda sendiri, silakan ubah "Metode Koneksi" menjadi <b>API Key Sendiri</b> pada pengaturan di bawah.</i>\n            </div>', '<div id="subExpiredNotice" style="display: none; margin-top: 15px; padding: 12px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 10px; color: #fca5a5; font-size: 12px; text-align: center; line-height: 1.5;" data-i18n="ui_sub_expired_notice">\n               ⚠️ Paket sewa API Anda telah berakhir. <br>Silakan perpanjang untuk terus menggunakan AI tanpa batas!<br><br>\n               💡 <i>Atau jika Anda ingin menggunakan API Anda sendiri, silakan ubah "Metode Koneksi" menjadi <b>API Key Sendiri</b> pada pengaturan di bawah.</i>\n            </div>'),
    ('<div id="deviceLimitNotice" style="display: none; margin-top: 15px; padding: 12px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 10px; color: #fca5a5; font-size: 12px; text-align: center;">\n               ⚠️ <b>Batas Perangkat Tercapai</b><br>Satu akun hanya boleh digunakan di 2 perangkat / browser / profil yang berbeda. Silakan logout dari perangkat lain terlebih dahulu.\n            </div>', '<div id="deviceLimitNotice" style="display: none; margin-top: 15px; padding: 12px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 10px; color: #fca5a5; font-size: 12px; text-align: center;" data-i18n="ui_device_limit_notice">\n               ⚠️ <b>Batas Perangkat Tercapai</b><br>Satu akun hanya boleh digunakan di 2 perangkat / browser / profil yang berbeda. Silakan logout dari perangkat lain terlebih dahulu.\n            </div>'),
    ('<div class="price-tag">Rp 10.000</div>', '<div class="price-tag" data-i18n="ui_price_tag">Rp 10.000</div>'),
    ('<div class="price-desc">Akses Penuh Selama 1 Bulan</div>', '<div class="price-desc" data-i18n="ui_price_desc">Akses Penuh Selama 1 Bulan</div>'),
    ('</svg> Masuk dengan Google\n            </button>', '</svg> <span data-i18n="ui_login_google">Masuk dengan Google</span>\n            </button>'),
    ('<div id="notLoggedInNotice" style="margin-top: 5px; margin-bottom: 15px; padding: 12px; background: rgba(255,255,255,0.05); border: 1px solid var(--border); border-radius: 10px; color: var(--text2); font-size: 12px; text-align: center; line-height: 1.5;">\n               💡 <i>Jika Anda ingin menggunakan API sendiri, silakan ubah "Metode Koneksi" menjadi <b>API Key Sendiri</b> pada pengaturan di bawah tanpa perlu login.</i>\n            </div>', '<div id="notLoggedInNotice" style="margin-top: 5px; margin-bottom: 15px; padding: 12px; background: rgba(255,255,255,0.05); border: 1px solid var(--border); border-radius: 10px; color: var(--text2); font-size: 12px; text-align: center; line-height: 1.5;" data-i18n="ui_not_logged_in_notice">\n               💡 <i>Jika Anda ingin menggunakan API sendiri, silakan ubah "Metode Koneksi" menjadi <b>API Key Sendiri</b> pada pengaturan di bawah tanpa perlu login.</i>\n            </div>'),
    ('<button id="buySubBtn" class="btn btn-green" style="width: 100%;" disabled>\n              ⚡ Sewa API Sekarang\n            </button>', '<button id="buySubBtn" class="btn btn-green" style="width: 100%;" disabled data-i18n="ui_rent_now">\n              ⚡ Sewa API Sekarang\n            </button>'),
    ('<button class="btn btn-outline" id="googleLogoutBtn" style="display:none; width: 100%; margin-top: 12px;">\n              Keluar Akun\n            </button>', '<button class="btn btn-outline" id="googleLogoutBtn" style="display:none; width: 100%; margin-top: 12px;" data-i18n="ui_logout">\n              Keluar Akun\n            </button>'),
    ('<div class="card-title">\n          <span class="icon">🔑</span> Gunakan API Sendiri\n        </div>', '<div class="card-title">\n          <span class="icon">🔑</span> <span data-i18n="ui_own_api_title">Gunakan API Sendiri</span>\n        </div>'),
    ('<p class="setting-desc" style="margin-top: -10px;">Gunakan kunci API dari Google AI Studio, Groq Console, atau Mistral Console\n          secara gratis.</p>', '<p class="setting-desc" style="margin-top: -10px;" data-i18n="ui_own_api_desc">Gunakan kunci API dari Google AI Studio, Groq Console, atau Mistral Console\n          secara gratis.</p>'),
    ('<textarea id="gemini-keys-input" class="keys-textarea"\n            placeholder="Tempel API Key Gemini di sini (satu per baris)..."></textarea>', '<textarea id="gemini-keys-input" class="keys-textarea"\n            placeholder="Tempel API Key Gemini di sini (satu per baris)..." data-i18n="ui_gemini_placeholder"></textarea>'),
    ('<div class="keys-help">\n            <span>📌</span> Ambil kunci di <a href="https://aistudio.google.com/app/apikey" target="_blank"', '<div class="keys-help">\n            <span>📌</span> <span data-i18n="ui_get_key_at">Ambil kunci di </span> <a href="https://aistudio.google.com/app/apikey" target="_blank"'),
    ('<button class="btn btn-primary" id="gemini-validate-btn" style="flex: 2;">Simpan & Validasi</button>', '<button class="btn btn-primary" id="gemini-validate-btn" style="flex: 2;" data-i18n="ui_save_validate">Simpan & Validasi</button>'),
    ('<button class="btn btn-danger" id="gemini-clear-btn" style="flex: 1;">Hapus</button>', '<button class="btn btn-danger" id="gemini-clear-btn" style="flex: 1;" data-i18n="ui_delete">Hapus</button>'),
    ('<textarea id="groq-keys-input" class="keys-textarea"\n            placeholder="Tempel API Key Groq di sini (satu per baris)..."></textarea>', '<textarea id="groq-keys-input" class="keys-textarea"\n            placeholder="Tempel API Key Groq di sini (satu per baris)..." data-i18n="ui_groq_placeholder"></textarea>'),
    ('<div class="keys-help">\n            <span>📌</span> Ambil kunci di <a href="https://console.groq.com/keys" target="_blank"', '<div class="keys-help">\n            <span>📌</span> <span data-i18n="ui_get_key_at">Ambil kunci di </span> <a href="https://console.groq.com/keys" target="_blank"'),
    ('<button class="btn btn-primary" id="groq-validate-btn" style="flex: 2;">Simpan & Validasi</button>', '<button class="btn btn-primary" id="groq-validate-btn" style="flex: 2;" data-i18n="ui_save_validate">Simpan & Validasi</button>'),
    ('<button class="btn btn-danger" id="groq-clear-btn" style="flex: 1;">Hapus</button>', '<button class="btn btn-danger" id="groq-clear-btn" style="flex: 1;" data-i18n="ui_delete">Hapus</button>'),
    ('<textarea id="mistral-keys-input" class="keys-textarea"\n            placeholder="Tempel API Key Mistral di sini (satu per baris)..."></textarea>', '<textarea id="mistral-keys-input" class="keys-textarea"\n            placeholder="Tempel API Key Mistral di sini (satu per baris)..." data-i18n="ui_mistral_placeholder"></textarea>'),
    ('<div class="keys-help">\n            <span>📌</span> Ambil kunci di <a href="https://console.mistral.ai/api-keys/" target="_blank"', '<div class="keys-help">\n            <span>📌</span> <span data-i18n="ui_get_key_at">Ambil kunci di </span> <a href="https://console.mistral.ai/api-keys/" target="_blank"'),
    ('<button class="btn btn-primary" id="mistral-validate-btn" style="flex: 2;">Simpan & Validasi</button>', '<button class="btn btn-primary" id="mistral-validate-btn" style="flex: 2;" data-i18n="ui_save_validate">Simpan & Validasi</button>'),
    ('<button class="btn btn-danger" id="mistral-clear-btn" style="flex: 1;">Hapus</button>', '<button class="btn btn-danger" id="mistral-clear-btn" style="flex: 1;" data-i18n="ui_delete">Hapus</button>'),
    ('<div class="card-title">\n          <span class="icon">⚙️</span> Pengaturan AI\n        </div>', '<div class="card-title">\n          <span class="icon">⚙️</span> <span data-i18n="ui_settings_title">Pengaturan AI</span>\n        </div>'),
    ('<label>Metode Koneksi</label>', '<label data-i18n="ui_conn_method">Metode Koneksi</label>'),
    ('<option value="proxy">Sewa API (Rekomendasi)</option>', '<option value="proxy" data-i18n="ui_conn_rent">Sewa API (Rekomendasi)</option>'),
    ('<option value="local">API Key Sendiri</option>', '<option value="local" data-i18n="ui_conn_own">API Key Sendiri</option>'),
    ('<label>Provider Default</label>', '<label data-i18n="ui_default_provider">Provider Default</label>'),
    ('<label>Target Keywords</label>', '<label data-i18n="ui_target_keywords">Target Keywords</label>'),
    ('<p class="setting-desc">Jumlah keyword yang direkomendasikan maksimal 35.</p>', '<p class="setting-desc" data-i18n="ui_target_keywords_desc">Jumlah keyword yang direkomendasikan maksimal 35.</p>'),
    ('<label>Bahasa Output</label>', '<label data-i18n="ui_output_lang">Bahasa Output</label>'),
    ('<label>Minimal Panjang Judul</label>', '<label data-i18n="ui_min_title">Minimal Panjang Judul</label>'),
    ('<p class="setting-desc">Panjang judul yg direkomendasikan adobe stock antara 70 sampai 120.</p>', '<p class="setting-desc" data-i18n="ui_min_title_desc">Panjang judul yg direkomendasikan adobe stock antara 70 sampai 120.</p>'),
    ('<div class="card-title">\n        <span class="icon">🤖</span> Pengisian Otomatis (Auto Fill)\n      </div>', '<div class="card-title">\n        <span class="icon">🤖</span> <span data-i18n="ui_autofill_title">Pengisian Otomatis (Auto Fill)</span>\n      </div>'),
    ('<p class="setting-desc">Aktifkan fitur ini agar AI mengisi form Adobe Stock secara otomatis setelah proses\n        selesai.</p>', '<p class="setting-desc" data-i18n="ui_autofill_desc">Aktifkan fitur ini agar AI mengisi form Adobe Stock secara otomatis setelah proses\n        selesai.</p>'),
    ('<label>Pilih Kategori Otomatis</label>', '<label data-i18n="ui_auto_category">Pilih Kategori Otomatis</label>'),
    ('<label>Tentukan Tipe File</label>', '<label data-i18n="ui_auto_filetype">Tentukan Tipe File</label>'),
    ('<label>Centang "No Release"</label>', '<label data-i18n="ui_check_no_release">Centang "No Release"</label>'),
    ('<label>Centang "Created with AI"</label>', '<label data-i18n="ui_check_created_ai">Centang "Created with AI"</label>'),
    ('<h4 style="color: var(--accent); margin-bottom: 5px;">🚀 Cloud Sync (Membutuhkan Login)</h4>', '<h4 style="color: var(--accent); margin-bottom: 5px;" data-i18n="ui_cloud_sync_title">🚀 Cloud Sync (Membutuhkan Login)</h4>'),
    ('<p class="setting-desc" style="margin-left: 0; line-height: 1.5;">Jika Anda punya lebih dari satu akun Adobe Stock, fitur ini bisa antisipasi/deteksi jika gambar atau video sudah pernah diupload di salah satu akun Anda. Semua akun yang mengisi Email Tim yang sama akan <b>berbagi satu database bersama</b>.</p>', '<p class="setting-desc" style="margin-left: 0; line-height: 1.5;" data-i18n="ui_cloud_sync_desc">Jika Anda punya lebih dari satu akun Adobe Stock, fitur ini bisa antisipasi/deteksi jika gambar atau video sudah pernah diupload di salah satu akun Anda. Semua akun yang mengisi Email Tim yang sama akan <b>berbagi satu database bersama</b>.</p>'),
    ('<label>Aktifkan Anti Duplikasi Upload</label>', '<label data-i18n="ui_enable_smart_upload">Aktifkan Anti Duplikasi Upload</label>'),
    ('<p class="setting-desc">Mengecek database sebelum upload untuk mencegah upload file yang sama 2x.</p>', '<p class="setting-desc" data-i18n="ui_enable_smart_upload_desc">Mengecek database sebelum upload untuk mencegah upload file yang sama 2x.</p>'),
    ('<label>Email Tim (Shared Pool)</label>', '<label data-i18n="ui_team_email">Email Tim (Shared Pool)</label>'),
    ('<button class="btn btn-outline" id="testDbBtn" style="border-color: #0984e3; color: #0984e3; padding: 6px 12px; font-size: 13px;">🔍 Test Sync</button>', '<button class="btn btn-outline" id="testDbBtn" style="border-color: #0984e3; color: #0984e3; padding: 6px 12px; font-size: 13px;" data-i18n="ui_test_sync">🔍 Test Sync</button>'),
    ('<p class="setting-desc">Isi dengan email yang sama di semua akun. Semua akun dengan email tim yang sama otomatis berbagi data upload.</p>', '<p class="setting-desc" data-i18n="ui_team_email_desc">Isi dengan email yang sama di semua akun. Semua akun dengan email tim yang sama otomatis berbagi data upload.</p>'),
    ('<button class="btn btn-outline" id="resetSettingsBtn">↺ Kembalikan Pengaturan Default</button>', '<button class="btn btn-outline" id="resetSettingsBtn" data-i18n="ui_reset_settings">↺ Kembalikan Pengaturan Default</button>'),
    ('<div class="card-title">\n        <span class="icon">🧪</span> Uji Coba Koneksi\n      </div>', '<div class="card-title">\n        <span class="icon">🧪</span> <span data-i18n="ui_test_conn_title">Uji Coba Koneksi</span>\n      </div>'),
    ('<label>Deskripsi Gambar</label>', '<label data-i18n="ui_image_desc">Deskripsi Gambar</label>'),
    ('<button class="btn btn-primary" id="testBtn" style="width: 100%;">\n        ▶ Jalankan Tes AI\n      </button>', '<button class="btn btn-primary" id="testBtn" style="width: 100%;" data-i18n="ui_run_test">\n        ▶ Jalankan Tes AI\n      </button>'),
    ('<h2>Penting!</h2>', '<h2 data-i18n="ui_modal_important">Penting!</h2>'),
    ('<p>Masukkan email yang terdaftar di akun ini saat proses pembayaran agar sistem kami bisa mengaktifkan status PRO\n        secara otomatis.</p>', '<p data-i18n="ui_modal_desc">Masukkan email yang terdaftar di akun ini saat proses pembayaran agar sistem kami bisa mengaktifkan status PRO\n        secara otomatis.</p>'),
    ('<button class="copy-btn-small" id="modalCopyBtn">Salin</button>', '<button class="copy-btn-small" id="modalCopyBtn" data-i18n="ui_copy">Salin</button>'),
    ('<button class="btn btn-outline" id="modalCancelBtn">Batal</button>', '<button class="btn btn-outline" id="modalCancelBtn" data-i18n="ui_cancel">Batal</button>'),
    ('<button class="btn btn-primary" id="modalConfirmBtn">Lanjut Bayar</button>', '<button class="btn btn-primary" id="modalConfirmBtn" data-i18n="ui_continue_pay">Lanjut Bayar</button>'),
]

for old, new in replacements:
    if old in content:
        content = content.replace(old, new)
    else:
        print(f'Could not find: {old[:50]}...')

ui_language_html = '''        <div class="setting-row">
          <label data-i18n="ui_language">Bahasa UI / UI Language</label>
          <select id="uiLanguage">
            <option value="id">Indonesia</option>
            <option value="en">English</option>
          </select>
        </div>'''
if '<label data-i18n="ui_output_lang">Bahasa Output</label>' in content:
    content = content.replace('<div class="setting-row">\n          <label data-i18n="ui_output_lang">Bahasa Output</label>', ui_language_html + '\n\n        <div class="setting-row">\n          <label data-i18n="ui_output_lang">Bahasa Output</label>')

with open('localSetup.html', 'w', encoding='utf-8') as f:
    f.write(content)

print('Updated localSetup.html')
