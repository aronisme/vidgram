// === DATABASE SYNC HANDLERS ===
const dbSyncHandler = (msg, sender, sendResponse) => {
  if (msg.target !== 'background') return false;

  if (msg.cmd === 'recordDb' || msg.cmd === 'checkBatchDb') {
    (async () => {
      try {
        const lGet = (key, fallback) => new Promise(r => chrome.storage.local.get({ [key]: fallback }, d => r(d[key])));
        const lSet = (key, val) => new Promise(r => chrome.storage.local.set({ [key]: val }, () => r()));
        let userAuth = await lGet('userAuth', null);
        const settings = await lGet('localSettings', {});
        const ownEmail = userAuth?.user?.email || null;
        const targetEmail = settings.syncEmail || ownEmail;

        if (!ownEmail || !userAuth?.token) {
          throw new Error("Silakan Login ulang di tab Sewa APIKey (Token tidak tersedia).");
        }

        const firebaseKey = "AIzaSyCNGYKxyqvqCrduHbl6BJ5a2AbBOJMsrz8";
        const projectId = "fast-proxy-ai";

        // Token Refresh Logic
        async function refreshIfNeeded(status) {
          if (status === 401 && userAuth.refreshToken) {
            const refreshRes = await fetch(`https://securetoken.googleapis.com/v1/token?key=${firebaseKey}`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
              body: `grant_type=refresh_token&refresh_token=${userAuth.refreshToken}`
            });
            if (refreshRes.ok) {
              const refreshData = await refreshRes.json();
              userAuth.token = refreshData.access_token;
              userAuth.refreshToken = refreshData.refresh_token;
              await lSet('userAuth', userAuth);
              return true;
            }
          }
          return false;
        }

        if (msg.cmd === 'recordDb') {
          // WRITE: Use ownEmail, and also syncEmail if set
          async function doPatch(email) {
            const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/users/${encodeURIComponent(email)}/uploads/${encodeURIComponent(msg.hash)}?key=${firebaseKey}`;
            return await fetch(url, {
              method: 'PATCH',
              headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${userAuth.token}` },
              body: JSON.stringify({
                fields: {
                  filename: { stringValue: msg.filename },
                  date: { stringValue: new Date().toISOString() },
                  hash: { stringValue: msg.hash },
                  uploadedBy: { stringValue: ownEmail } // Lacak siapa yang upload
                }
              })
            });
          }
          let res = await doPatch(ownEmail);
          if (res.status === 401 && await refreshIfNeeded(401)) res = await doPatch(ownEmail);
          if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(`DB Error (${res.status}): ${err?.error?.message || 'Unauthorized/Forbidden'}`);
          }

          if (settings.syncEmail && settings.syncEmail !== ownEmail) {
            let resSync = await doPatch(settings.syncEmail);
            if (resSync.status === 401 && await refreshIfNeeded(401)) resSync = await doPatch(settings.syncEmail);
            if (!resSync.ok) {
              const err = await resSync.json().catch(() => ({}));
              console.warn(`Sync DB Error: ${err?.error?.message}`);
            }
          }

          sendResponse({ success: true });
        } else {
          // READ: Check from ownEmail first, then syncEmail
          const duplicates = [];
          const results = {};

          async function checkDoc(email, h) {
            const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/users/${encodeURIComponent(email)}/uploads/${encodeURIComponent(h)}?key=${firebaseKey}`;
            let r = await fetch(url, { headers: { 'Authorization': `Bearer ${userAuth.token}` } });
            if (r.status === 401 && await refreshIfNeeded(401)) {
              r = await fetch(url, { headers: { 'Authorization': `Bearer ${userAuth.token}` } });
            }
            if (r.ok) {
              return await r.json();
            }
            return null;
          }

          await Promise.all(msg.hashes.map(async (h) => {
            let doc = await checkDoc(ownEmail, h);
            let foundEmail = ownEmail;

            if (!doc && settings.syncEmail && settings.syncEmail !== ownEmail) {
              doc = await checkDoc(settings.syncEmail, h);
              foundEmail = settings.syncEmail;
            }

            if (doc) {
              duplicates.push(h);
              results[h] = {
                exists: true,
                source: foundEmail,
                data: {
                  lastSeen: doc.fields?.date?.stringValue || new Date().toISOString(),
                  filename: doc.fields?.filename?.stringValue,
                  uploadedBy: doc.fields?.uploadedBy?.stringValue || foundEmail
                }
              };
            }
          }));
          sendResponse({ success: true, duplicates, results });
        }
      } catch (e) {
        sendResponse({ success: false, error: e.message, duplicates: [], results: {} });
      }
    })();
    return true;
  }
  return false;
};
dbSyncHandler._isLocalAiHandler = true;
chrome.runtime.onMessage.addListener(dbSyncHandler);

// === ORIGINAL BUNDLE ===
(() => { "use strict"; function t(t, e) { return new Promise((s => { const o = {}; o[t] = e, chrome.storage.local.set(o, (() => s(e))) })) } var e = function (t, e, s, o) { return new (s || (s = Promise))((function (h, p) { function c(t) { try { a(o.next(t)) } catch (t) { p(t) } } function r(t) { try { a(o.throw(t)) } catch (t) { p(t) } } function a(t) { var e; t.done ? h(t.value) : (e = t.value, e instanceof s ? e : new s((function (t) { t(e) }))).then(c, r) } a((o = o.apply(t, e || [])).next()) })) }; chrome.action.onClicked.addListener((t => { const e = function (t) { "/" === (t = t.toString().replace(/^https?:\/\//i, "")).charAt(0) && (t = window.location.hostname + t); return t.match(/^[^/:]+/) ? t : null }(t.url).split("/")[0], s = t.url.split("/").at(-1), o = "contributor.stock.adobe.com", h = "https://" + o + "/uploads"; e !== o ? chrome.tabs.create({ url: h }) : "uploads" != s && chrome.tabs.update(t.id, { url: h }) })), chrome.runtime.onMessage.addListener((s => (s && ["localProcess", "openLocalSetup", "validateKey", "nativeSync", "recordDb", "checkBatchDb"].includes(s.cmd)) ? false : e(void 0, void 0, void 0, (function* () { let o, d; switch (s.cmd) { case "openOffScreen": if ("background" !== s.target) return; yield function () { return e(this, void 0, void 0, (function* () { yield function (t) { return e(this, void 0, void 0, (function* () { (yield a()) || (r ? yield r : (r = chrome.offscreen.createDocument({ url: chrome.runtime.getURL(t), reasons: [chrome.offscreen.Reason.DOM_SCRAPING], justification: "authentication" }), yield r, r = null)) })) }(c); const s = yield function () { return new Promise(((t, s) => e(this, void 0, void 0, (function* () { const e = yield chrome.runtime.sendMessage({ type: "firebase-auth", target: "offscreen" }); "FirebaseError" !== (null == e ? void 0 : e.name) ? t(e) : s(e) })))) }().then((s => e(this, void 0, void 0, (function* () { return yield t("userAuth", s), Math.abs(s.user.createdAt - s.user.lastLoginAt) < 10 ? (yield i(!0), yield function (t) { return e(this, void 0, void 0, (function* () { const e = (yield function (t, e = !1) { return new Promise((s => { const o = {}; o[t] = e ? 0 : "", chrome.storage.sync.get(o, (e => s(e[t]))) })) }("emailArray")) || []; e.push(t.user.email); const s = new Set(e); var o; if (o = Array.from(s), new Promise((t => { const e = {}; e.emailArray = o, chrome.storage.sync.set(e, (() => t(o))) })), s.size > 2) try { chrome.tabs.create({ url: `https://warningspam-rx6xcb4xwa-uc.a.run.app?uid=${t.user.uid}&emails=${Array.from(s)}` }) } catch (t) { return console.log(t) } })) }(s)) : yield i(), s })))).catch((t => { if ("auth/operation-not-allowed" !== t.code) return console.error("Full Firebase Error", t.code, t.message, t), t; console.error("You must enable an OAuth provider in the Firebase console in order to use signInWithPopup. This sample uses Google by default.") })).finally(n); return s })) }(); break; case "open": switch (chrome.tabs.query({ currentWindow: !0, active: !0 }, (function (t) { d = t[0].id, chrome.storage.local.set({ nowTabId: d }) })), s.type) { case "original": o = s.keyword.replace(" ", "%20"), chrome.tabs.create({ url: "https://imstocker.com/en/keyworder?extension=true&q=" + o }); break; case "ai": case "title": chrome.tabs.create({ url: "https://chatgpt.com/?extension=true" }); break; case "aiBard": case "titleBard": chrome.tabs.create({ url: "https://gemini.google.com/app?extension=true" }); break; case "downloadOffscreen": chrome.tabs.create({ url: chrome.runtime.getURL("downloadOffscreen.html") }) }break; case "uploadImg": if ("background" !== s.target || !s.data) return; chrome.tabs.query({ currentWindow: !0, active: !0 }, (t => { chrome.tabs.sendMessage(t[0].id, { cmd: "uploadImgContent", target: "content", data: s.data }) })); break; case "fillResult": case "fillHistoryResult": if ("background" !== s.target || !s.data) return; chrome.tabs.query({ currentWindow: !0, active: !0 }, (t => { chrome.tabs.sendMessage(t[0].id, { cmd: s.cmd, target: "content", data: s.data }) })); break; case "copyKeyword": chrome.storage.local.get(["nowTabId"], (t => { let e = "pasteKeywords"; switch (s.type) { case "ai": case "aiBard": e = "pasteKeywords"; break; case "title": case "titleBard": e = "pasteTitle" }chrome.tabs.sendMessage(parseInt(t.nowTabId), { cmd: e }, (() => { chrome.tabs.query({ currentWindow: !0, active: !0 }, (function (e) { var s; s = e[0].id, chrome.storage.local.get({ adTime: 0, autoClose: !1 }, (t => { const e = Date.now(); 0 === t.adTime ? (chrome.storage.local.set({ adTime: h(6) }), chrome.tabs.remove(s)) : e >= t.adTime ? function (t) { chrome.storage.local.get({ adsType: !1, adRecent: !1, adRecentTabId: 0 }, (e => { const s = e.adsType; parseInt(e.adRecentTabId); chrome.storage.local.set({ adsType: !s, adRecent: !0, adRecentTabId: t, adTime: h(6) }), p(t, s) })) }(s) : chrome.tabs.remove(parseInt(s)) })), chrome.tabs.update(parseInt(t.nowTabId), { active: !0 }) })) })) })); break; case "openLogin": o = s.keyword.replace(" ", "%20"), chrome.tabs.query({ currentWindow: !0, active: !0 }, (function (t) { chrome.tabs.update(t[0].id, { url: "https://imstocker.com/en/keyworder?q=" + o }) })); break; case "loginUser": if ("background" !== s.target) return; yield i(); break; case "closeTab": if ("background" !== s.target) return; chrome.storage.local.get("nowTabId", (({ nowTabId: t }) => { chrome.tabs.query({ active: !0, currentWindow: !0 }, (([e]) => { chrome.tabs.update(t, { active: !0 }), chrome.tabs.remove(e.id) })) })); break; case "openDrawerFromBackground": if ("background" !== s.target) return; chrome.tabs.query({ active: !0, lastFocusedWindow: !0 }, (([s]) => e(void 0, void 0, void 0, (function* () { yield t("loginTabID", s.id), chrome.tabs.sendMessage(s.id, { cmd: "openDrawer" }) })))); break; case "openHistory": if ("background" !== s.target) return; chrome.tabs.query({ currentWindow: !0, active: !0 }, (([t]) => { chrome.sidePanel.open({ tabId: t.id }) })); break; case "closeOffscreen": if ("background" !== s.target) return; yield n(); break } })))); const s = /https:\/\/contributor\.stock\.adobe\.com\/(.+)\/upload[s]$/i, o = /https:\/\/contributor\.stock\.adobe\.com(.*)$/i; function h(t) { return Date.now() + 60 * parseInt(t) * 60 * 1e3 } function p(t, e, s = !1) { let o; o = s ? [] : e ? ["https://s.shopee.co.th/8fL4Jk9P7v", "https://s.shopee.co.th/9pX1ht4xlA", "https://s.shopee.co.th/9fDbVa5b69", "https://s.shopee.co.th/9UuBJH6ER8", "https://s.shopee.co.th/9Kal6y6rm7", "https://s.shopee.co.th/AUmiV72QPM", "https://s.shopee.co.th/AKTIIo33kL", "https://s.shopee.co.th/AA9s6V3h5K", "https://s.shopee.co.th/9zqRuC4KQJ", "https://s.shopee.co.th/5q0swXKBsW", "https://s.shopee.co.th/5fhSkEKpDV", "https://s.shopee.co.th/5VO2XvLSYU", "https://s.shopee.co.th/5L4cLcM5tT", "https://s.shopee.co.th/6VGZjlHeWi", "https://s.shopee.co.th/6Kx9XSIHrh", "https://s.shopee.co.th/6AdjL9IvCg", "https://s.shopee.co.th/60KJ8qJYXf", "https://s.shopee.co.th/7AWGWzF7Au", "https://s.shopee.co.th/70CqKgFkVt", "https://s.shopee.co.th/6ptQ8NGNqs", "https://s.shopee.co.th/6fZzw4H1Br", "https://s.shopee.co.th/7plxKDCZp6", "https://s.shopee.co.th/7fSX7uDDA5", "https://s.shopee.co.th/7V96vbDqV4", "https://s.shopee.co.th/7KpgjIETq3", "https://s.shopee.co.th/3B07ldULIG", "https://s.shopee.co.th/30ghZKUydF", "https://s.shopee.co.th/2qNHN1VbyE", "https://s.shopee.co.th/2g3rAiWFJD", "https://s.shopee.co.th/3qFoYrRnwS", "https://s.shopee.co.th/3fwOMYSRHR", "https://s.shopee.co.th/3VcyAFT4cQ", "https://s.shopee.co.th/3LJXxwThxP", "https://s.shopee.co.th/4VVVM5PGae", "https://s.shopee.co.th/4LC59mPtvd", "https://s.shopee.co.th/4AsexTQXGc", "https://s.shopee.co.th/40ZElARAbb", "https://s.shopee.co.th/5AlC9JMjEq", "https://s.shopee.co.th/50Rlx0NMZp", "https://s.shopee.co.th/4q8LkhNzuo", "https://s.shopee.co.th/4fovYOOdFn", "https://s.shopee.co.th/VzMajeUi0", "https://s.shopee.co.th/LfwOQf82z", "https://s.shopee.co.th/BMWC7flNy", "https://s.shopee.co.th/135zogOix", "https://s.shopee.co.th/1BF3NxbxMC", "https://s.shopee.co.th/10vdBecahB", "https://s.shopee.co.th/qcCzLdE2A", "https://s.shopee.co.th/gImn2drN9", "https://s.shopee.co.th/1qUkBBZQ0O", "https://s.shopee.co.th/1gBJysa3LN", "https://s.shopee.co.th/1VrtmZaggM", "https://s.shopee.co.th/1LYTaGbK1L", "https://s.shopee.co.th/2VkQyPWsea", "https://s.shopee.co.th/2LR0m6XVzZ", "https://s.shopee.co.th/2B7aZnY9KY", "https://s.shopee.co.th/20oANUYmfX", "https://s.shopee.co.th/8KiDv8Afom", "https://s.shopee.co.th/8V1e7RA2Tp", "https://s.shopee.co.th/805NWWBwUk", "https://s.shopee.co.th/8AOnipBJ9n", "https://s.shopee.co.th/8zxuiM88Sy", "https://s.shopee.co.th/9AHKuf7V81", "https://s.shopee.co.th/8fL4Jk9P8w", "https://s.shopee.co.th/8peUW38lnz", "https://s.shopee.co.th/9fDbVa5b7A", "https://s.shopee.co.th/9pX1ht4xmD", "https://s.shopee.co.th/9Kal6y6rn8", "https://s.shopee.co.th/9UuBJH6ESB", "https://s.shopee.co.th/AKTIIo33lM", "https://s.shopee.co.th/AUmiV72QQP", "https://s.shopee.co.th/9zqRuC4KRK", "https://s.shopee.co.th/AA9s6V3h6N", "https://s.shopee.co.th/5fhSkEKpEW", "https://s.shopee.co.th/5q0swXKBtZ", "https://s.shopee.co.th/5L4cLcM5uU", "https://s.shopee.co.th/5VO2XvLSZX", "https://s.shopee.co.th/6Kx9XSIHsi", "https://s.shopee.co.th/6VGZjlHeXl", "https://s.shopee.co.th/60KJ8qJYYg", "https://s.shopee.co.th/6AdjL9IvDj", "https://s.shopee.co.th/70CqKgFkWu", "https://s.shopee.co.th/7AWGWzF7Bx", "https://s.shopee.co.th/6fZzw4H1Cs", "https://s.shopee.co.th/6ptQ8NGNrv", "https://s.shopee.co.th/7fSX7uDDB6"] : ["https://s.shopee.co.th/1Vrtmg33sO", "https://s.shopee.co.th/1LYTaN3hDN", "https://s.shopee.co.th/1qUkBI1nCU", "https://s.shopee.co.th/1gBJyz2QXT", "https://s.shopee.co.th/2B7aZu0WWa", "https://s.shopee.co.th/20oANb19rZ", "https://s.shopee.co.th/2VkQyVzFqg", "https://s.shopee.co.th/2LR0mCztBf", "https://s.shopee.co.th/BMWCE88aG", "https://s.shopee.co.th/135zv8lvF", "https://s.shopee.co.th/VzMaq6ruM", "https://s.shopee.co.th/LfwOX7VFL", "https://s.shopee.co.th/qcCzS5bES", "https://s.shopee.co.th/gImn96EZR", "https://s.shopee.co.th/1BF3O44KYY", "https://s.shopee.co.th/10vdBl4xtX", "https://s.shopee.co.th/4AsexZsuTA", "https://s.shopee.co.th/40ZElGtXo9", "https://s.shopee.co.th/4VVVMBrdnG", "https://s.shopee.co.th/4LC59ssH8F", "https://s.shopee.co.th/4q8LknqN7M", "https://s.shopee.co.th/4fovYUr0SL", "https://s.shopee.co.th/5AlC9Pp6RS", "https://s.shopee.co.th/50Rlx6pjmR", "https://s.shopee.co.th/2qNHN7xzB2", "https://s.shopee.co.th/2g3rAoycW1", "https://s.shopee.co.th/3B07ljwiV8", "https://s.shopee.co.th/30ghZQxLq7", "https://s.shopee.co.th/3VcyALvRpE", "https://s.shopee.co.th/3LJXy2w5AD", "https://s.shopee.co.th/3qFoYxuB9K", "https://s.shopee.co.th/3fwOMeuoUJ", "https://s.shopee.co.th/6ptQ8Til3w", "https://s.shopee.co.th/6fZzwAjOOv", "https://s.shopee.co.th/7AWGX5hUO2", "https://s.shopee.co.th/70CqKmi7j1", "https://s.shopee.co.th/7V96vhgDi8", "https://s.shopee.co.th/7KpgjOgr37", "https://s.shopee.co.th/7plxKJex2E", "https://s.shopee.co.th/7fSX80faND", "https://s.shopee.co.th/5VO2Y1nplo", "https://s.shopee.co.th/5L4cLioT6n", "https://s.shopee.co.th/5q0swdmZ5u", "https://s.shopee.co.th/5fhSkKnCQt", "https://s.shopee.co.th/6AdjLFlIQ0", "https://s.shopee.co.th/60KJ8wlvkz", "https://s.shopee.co.th/6VGZjrk1k6", "https://s.shopee.co.th/6Kx9XYkf55", "https://s.shopee.co.th/9UuBJNYbei", "https://s.shopee.co.th/9Kal74ZEzh", "https://s.shopee.co.th/9pX1hzXKyo", "https://s.shopee.co.th/9fDbVgXyJn", "https://s.shopee.co.th/AA9s6bW4Iu", "https://s.shopee.co.th/9zqRuIWhdt", "https://s.shopee.co.th/AUmiVDUnd0", "https://s.shopee.co.th/AKTIIuVQxz", "https://s.shopee.co.th/8AOnivdgMa", "https://s.shopee.co.th/805NWceJhZ", "https://s.shopee.co.th/8V1e7XcPgg", "https://s.shopee.co.th/8KiDv8Afom", "https://s.shopee.co.th/8peUW9b90m", "https://s.shopee.co.th/8fL4JqbmLl", "https://s.shopee.co.th/9AHKulZsKs", "https://s.shopee.co.th/8zxuiSaVfr", "https://s.shopee.co.th/1LYTaN3hEO", "https://s.shopee.co.th/1Vrtmg33tR", "https://s.shopee.co.th/1gBJyz2QYU", "https://s.shopee.co.th/1qUkBI1nDX", "https://s.shopee.co.th/20oANb19sa", "https://s.shopee.co.th/2B7aZu0WXd", "https://s.shopee.co.th/2LR0mCztCg", "https://s.shopee.co.th/2VkQyVzFrj", "https://s.shopee.co.th/135zv8lwG", "https://s.shopee.co.th/BMWCE88bJ", "https://s.shopee.co.th/LfwOX7VGM", "https://s.shopee.co.th/VzMaq6rvP", "https://s.shopee.co.th/gImn96EaS", "https://s.shopee.co.th/qcCzS5bFV", "https://s.shopee.co.th/10vdBl4xuY", "https://s.shopee.co.th/1BF3O44KZb", "https://s.shopee.co.th/40ZElGtXpA", "https://s.shopee.co.th/4AsexZsuUD", "https://s.shopee.co.th/4LC59ssH9G", "https://s.shopee.co.th/4VVVMBrdoJ", "https://s.shopee.co.th/4fovYUr0TM", "https://s.shopee.co.th/4q8LknqN8P", "https://s.shopee.co.th/50Rlx6pjnS", "https://s.shopee.co.th/5AlC9Pp6SV", "https://s.shopee.co.th/2g3rAoycX2", "https://s.shopee.co.th/2qNHN7xzC5", "https://s.shopee.co.th/30ghZQxLr8", "https://s.shopee.co.th/3B07ljwiWB", "https://s.shopee.co.th/3LJXy2w5BE", "https://s.shopee.co.th/3VcyALvRqH", "https://s.shopee.co.th/3fwOMeuoVK", "https://s.shopee.co.th/3qFoYxuBAN", "https://s.shopee.co.th/6fZzwAjOPw", "https://s.shopee.co.th/6ptQ8Til4z", "https://s.shopee.co.th/70CqKmi7j1", "https://s.shopee.co.th/7AWGX5hUP5"]; const h = o[Math.floor(Math.random() * o.length)]; chrome.tabs.update(parseInt(t), { url: h }) } chrome.tabs.onUpdated.addListener(((t, e) => { if (e.url) { if (!o.test(e.url)) return; s.test(e.url) ? chrome.tabs.sendMessage(t, { cmd: "createBtn" }) : chrome.tabs.sendMessage(t, { cmd: "dismissAllToast", target: "content" }) } })); const c = "/offscreen.html"; let r; function a() { return e(this, void 0, void 0, (function* () { return (yield chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"], documentUrls: [chrome.runtime.getURL(c)] })).length > 0 })) } function n() { return e(this, void 0, void 0, (function* () { (yield a()) && (yield chrome.offscreen.closeDocument()) })) } function i(t = !1) { return e(this, void 0, void 0, (function* () { const e = yield function (t, e = !1) { return new Promise((s => { const o = {}; o[t] = e ? 0 : "", chrome.storage.local.get(o, (e => s(e[t]))) })) }("loginTabID"); if (e) try { chrome.tabs.sendMessage(parseInt(e), { cmd: "login", target: "content", data: t }) } catch (t) { console.log(t) } })) } })();

// === LOCAL AI HANDLER (REVERTED MODELS) ===
(function () {
  const GEMINI_MODEL = 'gemini-2.5-flash';
  const GROQ_MODEL = 'meta-llama/llama-4-scout-17b-16e-instruct';
  const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/models';
  const GROQ_BASE = 'https://api.groq.com/openai/v1/chat/completions';

  function lGet(k, f = '') { return new Promise(r => { const o = {}; o[k] = f; chrome.storage.local.get(o, d => r(d[k])) }) }
  function lSet(k, v) { return new Promise(r => { const o = {}; o[k] = v; chrome.storage.local.set(o, () => r(v)) }) }

  function buildKwPrompt(name, maxKw = 49, lang = 'id', hasImage = false, concept = '') {
    const langMap = { 'en': 'English', 'id': 'Indonesian', 'th': 'Thai', 'ja': 'Japanese', 'ko': 'Korean', 'zh': 'Chinese', 'es': 'Spanish' };
    const langName = langMap[lang] || 'English';
    const ln = lang !== 'en' ? ` Respond in ${langName} language.` : '';
    const cn = concept ? ` Focus on the concept/topic: "${concept}". Make sure keywords are relevant to this concept.` : '';
    
    // Calculate keyword layer distribution
    const primaryCount = Math.round(maxKw * 0.20);
    const secondaryCount = Math.round(maxKw * 0.20);
    const contextCount = Math.round(maxKw * 0.20);
    const styleCount = Math.round(maxKw * 0.17);
    const conceptualCount = maxKw - primaryCount - secondaryCount - contextCount - styleCount;
    
    const layeredRule = `
=== KEYWORD RULES (LAYERED SEO STRATEGY) ===
- Generate EXACTLY ${maxKw} unique ${langName} keyword tags, separated by commas only. No numbering, no extra text.
- LANGUAGE: All keywords must be in ${langName}. Do NOT mix languages.
- Layer keywords by purpose in this exact order:
  1. PRIMARY (first ~${primaryCount} tags): Exact subject descriptors — what IS in the image (nouns)
  2. SECONDARY (next ~${secondaryCount} tags): Actions, states, emotions visible or implied
  3. CONTEXT (next ~${contextCount} tags): Setting, location, environment, time of day
  4. STYLE (next ~${styleCount} tags): Lighting, visual technique, camera angles, color palette
  5. CONCEPTUAL (remaining ~${conceptualCount} tags): Abstract themes, broad concepts, utility (e.g., lifestyle, technology)
- FORMAT: Use singular nouns and infinitive verbs. NO MERGING words improperly. Use proper spaces.
- NO PEOPLE RULE: If the image has NO people, you MUST include the tags for "no people" and "nobody" in ${langName}.`;

    if (hasImage) return `(important! please answer without conversation with me.) Analyze this image carefully. Generate EXACTLY ${maxKw} unique ${langName} keyword tags (not more, not less, exactly ${maxKw} tags) that accurately describe what you see in this image. Include objects, actions, emotions, colors, settings, concepts, and styles visible in the image.${cn}${layeredRule} Separate with commas only, no numbering, no extra text. Arrange by relevance. The result must be a string of exactly ${maxKw} comma-separated tags only.${ln}`;
    return `(important! please answer without conversation with me.) Use your stock photos websites knowledge and imagine the sentences "${name}" as a picture and make EXACTLY ${maxKw} unique ${langName} tags (not more, not less, exactly ${maxKw} tags) which the most relate to (also include main words of sentence) for describe this picture.${cn}${layeredRule} No order number or no any sign in front of tags, just use comma sign to separate tags, no other sentence just the tags only, arrange tags by most popular tags first, no image or no link or addition information sentences at the end. The result must be a string with exactly ${maxKw} comma-separated tags.${ln}`;
  }

  function buildTitlePrompt(ts, ks, lang = 'id', concept = '', minTL = 70) {
    const langMap = { 'en': 'English', 'id': 'Indonesian', 'th': 'Thai', 'ja': 'Japanese', 'ko': 'Korean', 'zh': 'Chinese', 'es': 'Spanish' };
    const langName = langMap[lang] || 'English';
    const ln = lang !== 'en' ? ` Respond in ${langName} language.` : '';
    const cn = concept ? ` The title must strongly relate to the concept: "${concept}".` : '';
    // Calculate targeted optimal length
    let targetMax = 200;
    let targetMin = minTL || 70;

    return `(important! answer ONLY the title string, no other text, no quotes, no explanation.)

You are an Adobe Stock SEO title expert. Create ONE highly descriptive, search-optimized title for a stock photo in ${langName} language.

Context clues: "${ts}"
Keyword clues: "${ks}"
${cn}

=== TITLE RULES (BUYER-INTENT SEO) ===
- LENGTH: MUST be ${targetMin}–${targetMax} characters. Aim close to ${targetMax}. Use the full character budget.
- BUYER INTENT: Think like a stock photo BUYER. What search query would lead them to this image? Front-load the most searchable terms at the start of the title.
- STRUCTURE: [Main Subject] + [Action/State] + [Setting/Context] + [Mood/Atmosphere] + [Visual Style]
- FORMAT: No quotes, no periods at the end, no colons, no special characters. Sentence case or Title Case.
- NATURAL LANGUAGE: Flowing descriptive phrases, NOT a comma-separated keyword list.
- FORBIDDEN: No brand names, no camera specs (Canon, 85mm, 4k), no real people's names, no meta words (stock photo, image, wallpaper).
- Output ONLY the title string, nothing else.${ln}`;
  }

  function buildCombinedPrompt(maxKw = 49, minTL = 70, lang = 'en', hasImage = false, imgName = '', concept = '') {
    const langMap = { 'en': 'English', 'id': 'Indonesian', 'th': 'Thai', 'ja': 'Japanese', 'ko': 'Korean', 'zh': 'Chinese', 'es': 'Spanish' };
    const langName = langMap[lang] || 'English';
    const ln = lang !== 'en' ? ` All output text must be in ${langName} language.` : '';
    const cn = concept ? `\nFOCUS CONCEPT: "${concept}" — title and keywords must strongly revolve around this topic.` : '';
    const imageCtx = hasImage
      ? 'Analyze this image carefully and precisely. Identify: main subject(s), actions/poses, environment/setting, lighting quality, color palette, mood/atmosphere, and visual style (photographic vs artistic).'
      : `Imagine the description "${imgName}" as a real stock photo. Visualize specific details: the subject, setting, atmosphere, lighting, colors, composition, and style.`;

    // Calculate targeted optimal length
    let targetMax = 200;
    let targetMin = minTL || 70;

    // Calculate keyword layer distribution
    const primaryCount = Math.round(maxKw * 0.20);
    const secondaryCount = Math.round(maxKw * 0.20);
    const contextCount = Math.round(maxKw * 0.20);
    const styleCount = Math.round(maxKw * 0.17);
    const conceptualCount = maxKw - primaryCount - secondaryCount - contextCount - styleCount;

    return `(important! Follow the format EXACTLY. No conversation, no explanation.)

${imageCtx}${cn}

You are a top-performing Adobe Stock contributor and SEO expert. Generate a title, keywords, category, and file type for this stock image in ${langName} language in a SINGLE response.${ln}

You MUST format your response EXACTLY like this (including the labels):
TITLE: [your title here]
KEYWORDS: [comma-separated keywords here]
CATEGORY: [one category from the list below]
FILE_TYPE: [Photo or Illustration]

=== FILE_TYPE RULES (CRITICAL) ===
- PHOTO: ONLY for realistic images that look like they were taken with a physical camera. Natural lighting, real human skin textures, real-world physics, no digital manipulation artifacts.
- ILLUSTRATION: For EVERYTHING ELSE, including: 3D renders, vector art, digital paintings, abstract backgrounds, AI-generated art, composites, or anything with surreal/non-photographic qualities. If in doubt, choose Illustration.

=== CATEGORY (Choose exactly ONE) ===
Animals, Buildings and Architecture, Business, Drinks, The Environment, States of Mind, Food, Graphic Resources, Hobbies and Leisure, Industry, Landscape, Lifestyle, People, Plants and Flowers, Culture and Religion, Science, Social Issues, Sports, Technology, Transport, Travel

Category decision guide:
- Real people prominent → People or Lifestyle
- Building/interior focus → Buildings and Architecture
- Close-up nature → Plants and Flowers or Animals
- Wide nature scene → Landscape or The Environment
- Commercial/work context → Business or Technology
- Food close-up → Food; Beverages → Drinks

=== TITLE RULES (BUYER-INTENT SEO) ===
- LENGTH: MUST be ${targetMin}–${targetMax} characters. Aim close to ${targetMax}. Use the full character budget.
- BUYER INTENT: Think like a stock photo BUYER. What search query would lead them to this image? Front-load the most searchable terms at the start of the title.
- STRUCTURE: [Main Subject] + [Action/State] + [Setting/Context] + [Mood/Atmosphere] + [Visual Style]
  Example: "Young professional woman working on laptop in bright modern home office with warm natural morning light and minimalist decor"
- FORMAT: No quotes, no periods at the end, no colons, no special characters. Sentence case or Title Case.
- NATURAL LANGUAGE: Flowing descriptive phrases, NOT a comma-separated keyword list.
- FORBIDDEN: No brand names, no camera specs (Canon, 85mm, 4k), no real people's names, no meta words (stock photo, image, wallpaper).

=== KEYWORD RULES (LAYERED SEO STRATEGY) ===
- Generate EXACTLY ${maxKw} unique ${langName} keyword tags, separated by commas only. No numbering, no extra text.
- LANGUAGE: All keywords must be in ${langName}. Do NOT mix languages.
- Layer keywords by purpose in this exact order:
  1. PRIMARY (first ~${primaryCount} tags): Exact subject descriptors — what IS in the image (nouns)
  2. SECONDARY (next ~${secondaryCount} tags): Actions, states, emotions visible or implied
  3. CONTEXT (next ~${contextCount} tags): Setting, environment, location type, time of day
  4. STYLE (next ~${styleCount} tags): Visual style, mood, lighting, color palette, composition
  5. CONCEPTUAL (last ~${conceptualCount} tags): Abstract concepts, use-cases, themes a buyer might search
- MIX: 60-70% single-word tags, 30-40% high-quality 2-3 word phrases.
- FORMAT: Singular nouns, infinitive verbs. Proper spaces between words.
- TITLE REINFORCEMENT: Key descriptive terms from the title MUST also appear in the keyword list.
- NO PEOPLE RULE: If NO people are visible, include "no people" and "nobody" tags.
- NO FILLER: Do NOT use meta words (stock photo, image, picture, wallpaper, illustration, vector, clipart, icon, graphic, screenshot).
- NO FILLER ADJECTIVES: Do NOT use generic filler (beautiful, amazing, stunning, wonderful, nice, good, great, best, perfect, awesome, lovely, pretty, gorgeous).
- NO BRANDS/CAMERA: No brand names, camera models, lens specs, or resolution specs.
- NO SYNONYM STACKING: Max 2 words from any synonym group (e.g., dog/canine/pup/puppy → pick only 2 most popular).

Output ONLY the four lines starting with TITLE:, KEYWORDS:, CATEGORY:, and FILE_TYPE: — absolutely nothing else.`;
  }



  function parseCombinedResponse(raw) {
    const titleMatch = raw.match(/TITLE:\s*(.+)/i);
    const kwMatch = raw.match(/KEYWORDS:\s*(.+)/i);
    const catMatch = raw.match(/CATEGORY:\s*(.+)/i);
    const ftMatch = raw.match(/FILE_TYPE:\s*(.+)/i);

    if (titleMatch && kwMatch) {
      return {
        title: titleMatch[1].trim(),
        keywords: kwMatch[1].trim(),
        category: catMatch ? catMatch[1].trim() : '',
        fileType: ftMatch ? ftMatch[1].trim() : ''
      };
    }
    // Fallback: try splitting by newline
    const lines = raw.split('\n').map(l => l.trim()).filter(Boolean);
    if (lines.length >= 2) {
      const res = {
        title: lines[0].replace(/^TITLE:\s*/i, ''),
        keywords: lines.slice(1).join(', ').replace(/^KEYWORDS:\s*/i, ''),
        category: '',
        fileType: ''
      };
      lines.forEach(l => {
        if (l.toUpperCase().startsWith('CATEGORY:')) res.category = l.replace(/^CATEGORY:\s*/i, '').trim();
        if (l.toUpperCase().startsWith('FILE_TYPE:')) res.fileType = l.replace(/^FILE_TYPE:\s*/i, '').trim();
      });
      return res;
    }
    return null;
  }

  async function callGemini(key, prompt, imgB64) {
    const parts = [];
    if (imgB64) { const m = imgB64.match(/^data:(.+?);base64,(.+)$/); if (m) parts.push({ inline_data: { mime_type: m[1], data: m[2] } }); }
    parts.push({ text: prompt });
    const r = await fetch(`${GEMINI_BASE}/${GEMINI_MODEL}:generateContent?key=${key}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts }], generationConfig: { temperature: 0.8, maxOutputTokens: 1500 }, safetySettings: [{ category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' }, { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' }, { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_NONE' }, { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' }] }) });
    if (!r.ok) { const e = await r.json().catch(() => ({})); throw { code: r.status, message: e?.error?.message || `HTTP ${r.status}`, retryable: r.status === 429 || r.status >= 500 }; }
    const d = await r.json(); const t = d?.candidates?.[0]?.content?.parts?.[0]?.text; if (!t) throw { code: 0, message: 'Empty Gemini response', retryable: false }; return t.trim();
  }

  async function callGroq(key, prompt, imgB64) {
    const messages = [];
    if (imgB64) {
      messages.push({
        role: 'user', content: [
          { type: 'image_url', image_url: { url: imgB64 } },
          { type: 'text', text: prompt }
        ]
      });
    } else {
      messages.push({ role: 'user', content: prompt });
    }
    const r = await fetch(GROQ_BASE, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` }, body: JSON.stringify({ model: GROQ_MODEL, messages, temperature: 0.8, max_tokens: 1500 }) });
    if (!r.ok) { const e = await r.json().catch(() => ({})); throw { code: r.status, message: e?.error?.message || `HTTP ${r.status}`, retryable: r.status === 429 || r.status >= 500 }; }
    const d = await r.json(); const t = d?.choices?.[0]?.message?.content; if (!t) throw { code: 0, message: 'Empty Groq response', retryable: false }; return t.trim();
  }

  async function callMistral(key, prompt, imgB64) {
    const messages = [];
    if (imgB64) {
      messages.push({
        role: 'user', content: [
          { type: 'image_url', image_url: { url: imgB64 } },
          { type: 'text', text: prompt }
        ]
      });
    } else {
      messages.push({ role: 'user', content: prompt });
    }
    const model = imgB64 ? 'pixtral-12b-2409' : 'mistral-tiny-latest';
    const r = await fetch('https://api.mistral.ai/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` }, body: JSON.stringify({ model: model, messages, temperature: 0.8, max_tokens: 1500 }) });
    if (!r.ok) { const e = await r.json().catch(() => ({})); throw { code: r.status, message: e?.error?.message || `HTTP ${r.status}`, retryable: r.status === 429 || r.status >= 500 }; }
    const d = await r.json(); const t = d?.choices?.[0]?.message?.content; if (!t) throw { code: 0, message: 'Empty Mistral response', retryable: false }; return t.trim();
  }

  async function callWithRotation(provider, prompt, imgB64) {
    const keys = await lGet(`localKeys_${provider}`, []);
    if (!keys || !keys.length) throw new Error(`Kunci API ${provider} belum dikonfigurasi.`);
    let idx = ((await lGet('localKeyIndex', {}))[provider] || 0) % keys.length;
    let last = null;
    for (let i = 0; i < keys.length; i++) {
      const ci = (idx + i) % keys.length;
      try {
        const res = provider === 'gemini' ? await callGemini(keys[ci], prompt, imgB64) :
          provider === 'groq' ? await callGroq(keys[ci], prompt, imgB64) :
            await callMistral(keys[ci], prompt, imgB64);
        const id = await lGet('localKeyIndex', {}); id[provider] = (ci + 1) % keys.length; await lSet('localKeyIndex', id);
        return res;
      } catch (e) { last = e; console.warn(`[Local] Key#${ci + 1} ${provider} failed:`, e.message); if (!e.retryable && e.code !== 429 && e.code !== 401) throw e; }
    }
    throw new Error(`Semua kunci ${provider} gagal: ${last?.message}`);
  }

  const localAiHandler = (msg, sender, sendResponse) => {
    if (msg.cmd === 'localProcess' && msg.target === 'background') {
      (async () => {
        try {
          const settings = await lGet('localSettings', {});
          const provider = await lGet('localProvider', 'gemini');
          const imgName = await lGet('imgName', '');
          const titleSuggest = await lGet('titleSuggest', '');
          const keySuggest = await lGet('keySuggest', '');
          const concept = settings.keyConcept || '';
          const minTL = settings.minTitleLength || 70;
          let prompt, imgB64 = msg.imageBase64 || null;

          if (!imgB64 && !msg.isTest) {
            throw new Error("Gambar tidak ditemukan. Proses dibatalkan karena ekstensi wajib menggunakan Image-to-Text metadata.");
          }

          if (msg.searchType === 'localAutoCombined') {
            // === COMBINED: Title + Keywords in ONE request ===
            const hasImage = !!imgB64;
            const maxKw = settings.maxKeywords || 35;
            prompt = buildCombinedPrompt(maxKw, minTL, settings.language || 'en', hasImage, imgName, concept);
          } else if (msg.searchType === 'localAi' || msg.searchType === 'localAiImg' || msg.searchType === 'proxy') {
            const hasImage = !!imgB64;
            prompt = buildKwPrompt(imgName, settings.maxKeywords || 35, settings.language || 'en', hasImage, concept);
          } else if (msg.searchType === 'localAutoTitle') {
            const ln = (settings.language || 'en') !== 'en' ? ` Respond in ${settings.language || 'en'} language.` : '';
            const cn = concept ? ` The title must strongly relate to the concept/topic: "${concept}".` : '';
            let targetMin = minTL || 70;
            let maxTL = 200;
            prompt = imgB64
              ? `(important! answer ONLY the title string, no other text, no quotes, no explanation.)

You are an Adobe Stock SEO title expert. Analyze this image carefully and create ONE highly descriptive, search-optimized title.
${cn}

=== TITLE RULES (BUYER-INTENT SEO) ===
- LENGTH: MUST be ${targetMin}–${maxTL} characters. Aim close to ${maxTL}. Use the full character budget.
- BUYER INTENT: Think like a stock photo BUYER. What search query would lead them to this image? Front-load the most searchable terms at the start of the title.
- STRUCTURE: [Main Subject] + [Action/State] + [Setting/Context] + [Mood/Atmosphere] + [Visual Style]
- FORMAT: No quotes, no periods at the end, no colons, no special characters. Sentence case or Title Case.
- NATURAL LANGUAGE: Flowing descriptive phrases, NOT a comma-separated keyword list.
- FORBIDDEN: No brand names, no camera specs (Canon, 85mm, 4k), no real people's names, no meta words (stock photo, image, wallpaper).
- Output ONLY the title string, nothing else.${ln}`
              : `(important! answer ONLY the title string, no other text, no quotes, no explanation.)

You are an Adobe Stock SEO title expert. Create ONE highly descriptive, search-optimized title for a stock photo described as: "${imgName}"
${cn}

=== TITLE RULES (BUYER-INTENT SEO) ===
- LENGTH: MUST be ${targetMin}–${maxTL} characters. Aim close to ${maxTL}. Use the full character budget.
- BUYER INTENT: Think like a stock photo BUYER. What search query would lead them to this image? Front-load the most searchable terms at the start of the title.
- STRUCTURE: [Main Subject] + [Action/State] + [Setting/Context] + [Mood/Atmosphere] + [Visual Style]
- FORMAT: No quotes, no periods at the end, no colons, no special characters. Sentence case or Title Case.
- NATURAL LANGUAGE: Flowing descriptive phrases, NOT a comma-separated keyword list.
- FORBIDDEN: No brand names, no camera specs (Canon, 85mm, 4k), no real people's names, no meta words (stock photo, image, wallpaper).
- Output ONLY the title string, nothing else.${ln}`;
          } else {
            prompt = buildTitlePrompt(titleSuggest, keySuggest, settings.language || 'en', concept, minTL);
          }
          let result;
          const apiBackend = await lGet('localApiBackend', 'proxy');
          if (apiBackend === 'proxy' || msg.searchType === 'proxy') {
            // === MULTI-SERVER PROXY WITH RANDOM SELECTION & FAILOVER ===
            let servers = await lGet('aiProxyServers', []);

            // Backward compatibility: jika array kosong, coba fallback ke single URL/token lama
            if (!servers || servers.length === 0) {
              const legacyUrl = await lGet('aiProxyUrl', '');
              const legacyToken = await lGet('aiProxyToken', '');
              if (legacyUrl && legacyToken) {
                servers = [{ id: 'legacy', url: legacyUrl, token: legacyToken }];
              }
            }

            if (!servers || servers.length === 0) {
              throw new Error("Sewa APIKey AI belum aktif. Silakan login dan sewa di menu Settings.");
            }

            // Shuffle servers secara random (Fisher-Yates) agar load terdistribusi merata
            const shuffled = [...servers];
            for (let i = shuffled.length - 1; i > 0; i--) {
              const j = Math.floor(Math.random() * (i + 1));
              [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
            }

            const bodyPayload = { prompt };
            if (imgB64) {
              const b64 = imgB64.includes('base64,') ? imgB64.split('base64,')[1] : imgB64;
              bodyPayload.image = { base64: b64, mime: "image/jpeg" };
            }
            const bodyStr = JSON.stringify(bodyPayload);

            const TIMEOUT_MS = 20000; // 20 detik timeout per server
            let lastError = null;
            let success = false;

            for (let round = 1; round <= 3; round++) {
              console.log(`[Proxy] Memulai percobaan ronde ke-${round}/3...`);
              for (const server of shuffled) {
                const controller = new AbortController();
                const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

                try {
                  console.log(`[Proxy] Mencoba server: ${server.id} (${server.url}) [Ronde ${round}]`);
                  const proxyReq = await fetch(server.url, {
                    method: "POST",
                    headers: { "Authorization": `Bearer ${server.token}`, "Content-Type": "application/json" },
                    body: bodyStr,
                    signal: controller.signal
                  });
                  clearTimeout(timer);

                  const proxyRes = await proxyReq.json().catch(() => ({}));
                  if (!proxyReq.ok || !proxyRes.ok) {
                    throw new Error(proxyRes?.error?.message || `Proxy error: ${proxyReq.status}`);
                  }

                  console.log(`[Proxy] Sukses dari server: ${server.id}`);
                  result = proxyRes.result;
                  success = true;
                  break; // Keluar dari loop server
                } catch (e) {
                  clearTimeout(timer);
                  const isTimeout = e.name === 'AbortError';
                  lastError = isTimeout ? new Error(`Server ${server.id} timeout (>${TIMEOUT_MS / 1000}s)`) : e;
                  console.warn(`[Proxy] Server ${server.id} gagal: ${lastError.message}. Mencoba server lain...`);
                }
              }
              if (success) {
                break; // Keluar dari loop ronde jika sukses
              }
              if (round < 3) {
                console.log(`[Proxy] Semua server gagal di ronde ${round}. Menunggu 1.5 detik sebelum ronde berikutnya...`);
                await new Promise(resolve => setTimeout(resolve, 1500));
              }
            }

            if (!success) {
              throw new Error(`Semua ${shuffled.length} proxy server gagal setelah 3 ronde percobaan. Error terakhir: ${lastError?.message}`);
            }
          } else {
            result = await callWithRotation(provider, prompt, imgB64);
          }

          // Parse combined response if applicable
          if (msg.searchType === 'localAutoCombined') {
            const parsed = parseCombinedResponse(result);
            if (parsed) {
              sendResponse({
                success: true,
                title: parsed.title,
                keywords: parsed.keywords,
                category: parsed.category,
                fileType: parsed.fileType
              });
            } else {
              sendResponse({ success: false, error: 'Gagal parsing respons AI. Format tidak sesuai.' });
            }
          } else {
            sendResponse({ success: true, result });
          }
        } catch (e) { sendResponse({ success: false, error: e.message || String(e) }); }
      })();
      return true;
    }

    if (msg.cmd === 'openLocalSetup') {
      chrome.tabs.create({ url: chrome.runtime.getURL('localSetup.html') });
      sendResponse({ success: true });
      return true;
    }

    if (msg.cmd === 'validateKey') {
      (async () => {
        try {
          if (msg.provider === 'gemini') {
            const url = `${GEMINI_BASE}/${GEMINI_MODEL}:generateContent?key=${msg.apiKey}`;
            const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: 'Say ok' }] }], generationConfig: { maxOutputTokens: 5 } }) });
            if (r.ok) sendResponse({ valid: true }); else { const e = await r.json().catch(() => ({})); sendResponse({ valid: false, error: e?.error?.message || `HTTP ${r.status}` }); }
          } else if (msg.provider === 'groq') {
            const r = await fetch(GROQ_BASE, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${msg.apiKey}` }, body: JSON.stringify({ model: GROQ_MODEL, messages: [{ role: 'user', content: 'Say ok' }], max_tokens: 5 }) });
            if (r.ok) sendResponse({ valid: true }); else { const e = await r.json().catch(() => ({})); sendResponse({ valid: false, error: e?.error?.message || `HTTP ${r.status}` }); }
          } else if (msg.provider === 'mistral') {
            const r = await fetch('https://api.mistral.ai/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${msg.apiKey}` }, body: JSON.stringify({ model: 'mistral-tiny-latest', messages: [{ role: 'user', content: 'Say ok' }], max_tokens: 5 }) });
            if (r.ok) sendResponse({ valid: true }); else { const e = await r.json().catch(() => ({})); sendResponse({ valid: false, error: e?.error?.message || `HTTP ${r.status}` }); }
          }
        } catch (e) { sendResponse({ valid: false, error: e.message }); }
      })();
      return true;
    }

    if (msg.cmd === 'nativeSync' && msg.target === 'background') {
      // Stub out nativeSync since we removed the local tracking system
      sendResponse({ success: false, error: 'Local tracking system is deprecated.' });
      return true;
    }



    return false;
  };
  localAiHandler._isLocalAiHandler = true;
  chrome.runtime.onMessage.addListener(localAiHandler);
})();