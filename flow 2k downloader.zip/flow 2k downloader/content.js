(function () {
    if (window.hasFlowDownloader) return;
    window.hasFlowDownloader = true;

    // Auto-click button dengan nama "Dismiss" atau "Tutup"
    setInterval(() => {
        let buttons = Array.from(document.querySelectorAll('button'));
        for (let btn of buttons) {
            let txt = btn.textContent.trim();
            if (txt === 'Dismiss' || txt === 'Tutup' || txt === 'Close') {
                console.log("[Flow Downloader] Auto-clicking button:", txt, btn);
                btn.click();
            }
        }
    }, 1000);

    let isDownloading = false;
    let statusText = "Idle";
    let downloadedIds = new Set();
    let originalZoom = "";
    let pendingVerificationQueue = [];

    // Pendengar antrean unduhan latar belakang
    document.addEventListener('FlowDownloadStarted', () => {
        if (pendingVerificationQueue.length > 0) {
            let successfulTileId = pendingVerificationQueue.shift(); // Ambil yang paling lama antre
            downloadedIds.add(successfulTileId);
            saveHistory();
            console.log(`[Flow Downloader] ✅ Latar Belakang: Unduhan ${successfulTileId} terverifikasi Chrome & masuk History.`);
        }
    });

    // Load history
    chrome.storage.local.get(['downloadedIds'], (result) => {
        if (result.downloadedIds) {
            downloadedIds = new Set(result.downloadedIds);
        }
    });

    function saveHistory() {
        chrome.storage.local.set({ downloadedIds: Array.from(downloadedIds) });
    }

    function showToast(message, type = 'info') {
        let toastContainer = document.getElementById('flow-toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'flow-toast-container';
            toastContainer.style.cssText = `
                position: fixed;
                bottom: 30px;
                right: 30px;
                z-index: 999999;
                display: flex;
                flex-direction: column;
                gap: 12px;
                pointer-events: none;
            `;
            document.body.appendChild(toastContainer);
        }

        let toast = document.createElement('div');
        let bgColor = type === 'error' ? '#ef4444' : type === 'warning' ? '#f59e0b' : type === 'success' ? '#10b981' : '#3b82f6';
        toast.style.cssText = `
            background-color: ${bgColor};
            color: white;
            padding: 14px 24px;
            border-radius: 8px;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            font-family: system-ui, -apple-system, sans-serif;
            font-size: 14px;
            font-weight: 600;
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            max-width: 350px;
            word-wrap: break-word;
        `;
        toast.textContent = message;
        toastContainer.appendChild(toast);

        // Animate in
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                toast.style.opacity = '1';
                toast.style.transform = 'translateY(0)';
            });
        });

        // Animate out after 3.5 seconds
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(20px)';
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.parentElement.removeChild(toast);
                }
            }, 300);
        }, 3500);
    }

    function updateStatus(text) {
        statusText = text;
        chrome.runtime.sendMessage({ action: "update_status", isDownloading, statusText }).catch(() => { });
    }

    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
        if (msg.action === "get_status") {
            sendResponse({ isDownloading, statusText });
        }
        else if (msg.action === "start_download") {
            if (!isDownloading) {
                isDownloading = true;
                updateStatus("Memulai...");
                startMassDownload(msg.resolution, msg.skipDownloaded, msg.batchDelay).catch(err => {
                    console.error(err);
                    isDownloading = false;
                    updateStatus("Error: " + err.message);
                    if (originalZoom) {
                        document.body.style.zoom = originalZoom;
                    }
                });
            }
            sendResponse({ success: true });
        }
        else if (msg.action === "stop_download") {
            isDownloading = false;
            updateStatus("Berhenti...");
            if (originalZoom) {
                document.body.style.zoom = originalZoom;
            }
            sendResponse({ success: true });
        }
        else if (msg.action === "clear_history") {
            downloadedIds.clear();
            saveHistory();
            sendResponse({ success: true });
        }
        else if (msg.action === "download_started") {
            // Memberitahu document bahwa unduhan benar-benar telah diterima oleh Chrome
            document.dispatchEvent(new CustomEvent('FlowDownloadStarted'));
        }
    });

    function sleep(ms) {
        return new Promise(r => setTimeout(r, ms));
    }

    function findMoreButton(tile) {
        console.log("Mencari tombol More secara struktural...");

        // 1. Cari <a> tag yang mengarah ke link edit
        let aTag = tile.querySelector('a[href*="/edit/"]');
        if (aTag) {
            let overlay = aTag.nextElementSibling;
            if (overlay && overlay.tagName === 'DIV') {
                let allDivs = Array.from(overlay.querySelectorAll('div'));
                if (allDivs.length > 0) {
                    let deepestDiv = allDivs[allDivs.length - 1];
                    console.log("Menemukan div terdalam di overlay:", deepestDiv);
                    return deepestDiv;
                }
            }
        }

        // 2. Fallback ke pencarian class statis
        let btn = tile.querySelector('[class*="GyxcJ"]');
        if (btn) {
            console.log("Menemukan tombol via class GyxcJ:", btn);
            return btn;
        }

        // 3. Fallback paling luar
        let fallback = tile.querySelector('span[data-state]') || tile;
        console.log("Menggunakan fallback pemicu:", fallback);
        return fallback;
    }

    function getScrollContainer() {
        // Coba target langsung kontainer resmi React Virtuoso
        let scroller = document.querySelector('[data-testid="virtuoso-scroller"]') ||
            document.querySelector('[data-virtuoso-scroller="true"]');
        if (scroller) {
            console.log("[Flow Downloader] Menemukan kontainer Virtuoso secara langsung:", scroller);
            return scroller;
        }

        // Fallback 1: Jalur anak-ke-induk dari tile yang ada
        let firstTile = document.querySelector('[data-tile-id]');
        if (firstTile) {
            let parent = firstTile.parentElement;
            while (parent && parent !== document.body) {
                if (parent.scrollHeight > parent.clientHeight + 100) {
                    console.log("[Flow Downloader] Menemukan kontainer scroll via jalur tile:", parent);
                    return parent;
                }
                parent = parent.parentElement;
            }
        }

        // Fallback 2: Pencarian div dengan threshold tinggi yang aman terhadap zoom (2500px)
        let divs = Array.from(document.querySelectorAll('div'));
        let bestContainer = null;
        let maxDiff = -1;

        for (let div of divs) {
            let diff = div.scrollHeight - div.clientHeight;
            if (diff > 200 && div.clientHeight < 2500) {
                if (diff > maxDiff) {
                    maxDiff = diff;
                    bestContainer = div;
                }
            }
        }
        return bestContainer || window;
    }

    function scrollContainerDown(container, px) {
        if (!container || container === window) {
            window.scrollBy({ top: px });
            console.log("[Flow Downloader] Scrolling main window (instant)");
        } else {
            container.scrollTop += px; // Mutasi scrollTop secara langsung, kebal bug zoom browser!
            console.log("[Flow Downloader] Scrolling container (direct scrollTop):", container.scrollTop);
        }
    }

    function getScrollPos(container) {
        if (!container || container === window) {
            return window.scrollY || document.documentElement.scrollTop;
        }
        return container.scrollTop;
    }

    async function findAndGetTile(tileId) {
        // Coba cari langsung di DOM
        let tile = document.querySelector(`[data-tile-id="${tileId}"]`);
        if (tile) return tile;

        console.log(`[Flow Downloader] Tile ${tileId} tidak di DOM. Mencari dengan scrolling...`);

        let lastScrollTop = -1;
        let consecutiveNoChange = 0;
        let activeContainer = getScrollContainer();

        // Kita scroll perlahan ke bawah untuk mencari tile tersebut
        while (isDownloading) {
            scrollContainerDown(activeContainer, 300); // 300px pada zoom 50%
            await sleep(800);

            tile = document.querySelector(`[data-tile-id="${tileId}"]`);
            if (tile) {
                console.log(`[Flow Downloader] Tile ${tileId} ditemukan setelah scroll!`);
                return tile;
            }

            let currentScrollTop = getScrollPos(activeContainer);
            if (currentScrollTop === lastScrollTop) {
                consecutiveNoChange++;
                if (consecutiveNoChange >= 5) {
                    console.log(`[Flow Downloader] Mentok bawah mencari ${tileId}. Mencoba scroll ke atas...`);
                    if (activeContainer === window) {
                        window.scrollTo({ top: 0 });
                    } else {
                        activeContainer.scrollTop = 0; // Kembalikan ke paling atas secara instan langsung pada properti DOM
                    }
                    await sleep(1500);
                    break;
                }
            } else {
                consecutiveNoChange = 0;
            }
            lastScrollTop = currentScrollTop;
        }

        return document.querySelector(`[data-tile-id="${tileId}"]`);
    }

    async function startMassDownload(resolutionText, skipDownloaded, batchDelaySeconds = 3) {
        console.log(`[Flow Downloader] Memulai mode scan + download presisi. Skip: ${skipDownloaded}, Delay: ${batchDelaySeconds}s`);

        // Simpan zoom asli dan perkecil halaman ke 50%
        originalZoom = document.body.style.zoom || "";
        document.body.style.zoom = "50%";
        console.log(`[Flow Downloader] Menyimpan zoom asli: ${originalZoom || "100%"} dan memperkecil ke 50%`);

        // Beri waktu bagi browser untuk menghitung ulang koordinat layout dengan zoom baru
        await sleep(800);

        updateStatus("Memulai Scan Proyek...");
        showToast("Mulai menyusuri galeri secara otomatis...", "info");

        // 1. Fase Pre-Scan: Scroll ke bawah untuk mendata seluruh media dan memicu loading
        let uniqueIds = new Set();
        let scrollSettled = false;
        let lastScrollTop = -1;
        let consecutiveNoChange = 0;

        // Kunci kontainer utama sejak awal agar tidak beralih ke panel dinamis lain!
        let activeContainer = getScrollContainer();
        console.log("[Flow Downloader] Fase 1: Memulai pemindaian total media dengan kontainer:", activeContainer);

        // Mulai dari paling atas secara instan
        if (activeContainer === window) {
            window.scrollTo({ top: 0 });
        } else {
            activeContainer.scrollTop = 0;
        }
        await sleep(1000);

        while (isDownloading && !scrollSettled) {
            // Catat ID yang ada di DOM saat ini
            let currentTiles = Array.from(document.querySelectorAll('[data-tile-id]'));
            for (let tile of currentTiles) {
                let id = tile.getAttribute('data-tile-id');
                // Pastikan bukan anak bersaram
                let isParent = true;
                let parent = tile.parentElement;
                while (parent) {
                    if (parent.hasAttribute('data-tile-id')) {
                        isParent = false;
                        break;
                    }
                    parent = parent.parentElement;
                }
                if (isParent && id) {
                    uniqueIds.add(id);
                }
            }

            updateStatus(`Memindai Galeri (${uniqueIds.size} media)...`);

            // Scroll kontainer jauh lebih cepat (500px)
            scrollContainerDown(activeContainer, 500);
            await sleep(300); // Jeda render sangat kilat (300ms)

            let currentScrollTop = getScrollPos(activeContainer);
            console.log(`[Flow Downloader] Pre-scan scroll position: ${currentScrollTop}, Last: ${lastScrollTop}`);

            if (currentScrollTop === lastScrollTop) {
                consecutiveNoChange++;
                // Karena sleep sekarang hanya 300ms, kita butuh ~15 loop untuk mencapai toleransi 4.5 detik menunggu API
                if (consecutiveNoChange >= 15) {
                    scrollSettled = true; // Mentok bawah
                }
            } else {
                consecutiveNoChange = 0;
            }
            lastScrollTop = currentScrollTop;
        }

        let masterList = Array.from(uniqueIds);
        console.log(`[Flow Downloader] Pemindaian selesai! Menemukan total ${masterList.length} media unik.`);
        showToast(`Selesai memindai! Menemukan total ${masterList.length} media. Memulai pengunduhan...`, 'success');

        // Pulihkan zoom halaman menjadi normal sebelum proses download dimulai
        if (originalZoom) {
            document.body.style.zoom = originalZoom;
        } else {
            document.body.style.zoom = "";
        }
        console.log(`[Flow Downloader] Memulihkan zoom halaman ke semula: ${originalZoom || "100%"}`);

        if (masterList.length === 0) {
            isDownloading = false;
            updateStatus("Idle (Tidak ada media)");
            alert("Tidak ditemukan media di halaman ini.");
            return;
        }

        // 2. Fase Kembali ke Atas
        updateStatus("Mempersiapkan Unduhan...");
        if (activeContainer === window) {
            window.scrollTo({ top: 0 });
        } else {
            activeContainer.scrollTop = 0; // Kembalikan ke paling atas secara instan langsung pada properti DOM
        }
        await sleep(2500); // Beri waktu kontainer beradaptasi ke zoom normal

        // 3. Fase Download Presisi Paralel (Dua-Dua)
        let successCount = 0;

        for (let i = 0; i < masterList.length; i += 2) {
            if (!isDownloading) break;

            // Siapkan batch isi maksimal 2 item
            let batch = [];
            if (i < masterList.length) batch.push({ index: i, id: masterList[i] });
            if (i + 1 < masterList.length) batch.push({ index: i + 1, id: masterList[i + 1] });

            let batchNames = batch.map(item => item.index + 1).join(" & ");
            let batchAnyProcessed = false;

            for (let item of batch) {
                if (!isDownloading) break;

                let tileId = item.id;
                let isDuplicate = downloadedIds.has(tileId);

                if (isDuplicate && skipDownloaded) {
                    console.log(`[Flow Downloader] 🚫 MELEWATI DUPLIKAT (Milik list ${item.index + 1}/${masterList.length}): ${tileId}`);
                    continue;
                }

                batchAnyProcessed = true;
                updateStatus(`Mendownload (${item.index + 1}/${masterList.length})`);

                // Temukan elemen tile secara dinamis
                let tile = await findAndGetTile(tileId);
                if (!tile) {
                    console.warn(`[Flow Downloader] Lewati tile ${tileId} karena tidak muncul di DOM.`);
                    continue;
                }

                tile.scrollIntoView({ behavior: 'smooth', block: 'center' });
                await sleep(1000); // Tunggu scroll selesai

                let success = await processTile(tile, resolutionText, tileId);
                if (success) {
                    successCount++;
                    updateStatus(`Berhasil dipicu (${item.index + 1}/${masterList.length})`);
                } else {
                    console.warn("[Flow Downloader] Gagal mendownload tile:", tileId);
                    updateStatus(`Gagal (${item.index + 1}/${masterList.length})`);
                    await sleep(1000);
                }

                // Jeda super singkat antar pemicu klik di batch yang sama agar menu tertutup dan siap memicu yang kedua
                await sleep(1000);
            }

            // Jeda antar batch HANYA jika ada media dalam batch ini yang benar-benar diproses (tidak diskip duplikat)
            if (isDownloading && batchAnyProcessed) {
                let delayMs = batchDelaySeconds * 1000;
                console.log(`[Flow Downloader] Batch ${batchNames} selesai dipicu. Istirahat ${delayMs}ms...`);
                await sleep(delayMs);
            }
        }

        isDownloading = false;

        // Pulihkan zoom halaman
        if (originalZoom) {
            document.body.style.zoom = originalZoom;
        }

        updateStatus(`Selesai! (${successCount} berhasil)`);

        setTimeout(() => {
            showToast(`Tugas Selesai! Berhasil mengunduh ${successCount} dari ${masterList.length} media.`, 'success');
        }, 500);
    }

    async function processTile(tile, resolutionText, tileId) {
        return new Promise(async (resolve) => {
            updateStatus("Menyiapkan Gambar...");

            // Simulasi Hover agar overlay menu muncul
            tile.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
            tile.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
            await sleep(500);

            let trigger = findMoreButton(tile);
            let menuOpened = false;

            updateStatus("Membuka Menu Opsi...");

            // Coba klik bertahap naik ke atas hierarki DOM dari tombol terdalam sampai batas aman
            let elementToClick = trigger;
            let limit = 0;

            while (elementToClick && elementToClick !== tile && limit < 5) {
                console.log("[Flow Downloader] Mencoba Klik Kiri pada:", elementToClick);
                elementToClick.click();

                await sleep(400);

                let menu = document.querySelector('[role="menu"]') || document.querySelector('[data-radix-menu-content]');
                if (menu) {
                    menuOpened = true;
                    console.log("[Flow Downloader] Menu Radix berhasil muncul via Klik Kiri!");
                    break;
                }

                elementToClick = elementToClick.parentElement;
                limit++;
            }

            // Jika klik kiri gagal, coba klik kanan bertahap naik ke atas hierarki DOM
            if (!menuOpened) {
                console.log("[Flow Downloader] Klik kiri gagal. Mencoba Klik Kanan...");
                let elementToRightClick = trigger;
                limit = 0;

                while (elementToRightClick && elementToRightClick !== tile && limit < 5) {
                    console.log("[Flow Downloader] Mencoba Klik Kanan pada:", elementToRightClick);
                    const rect = elementToRightClick.getBoundingClientRect();
                    elementToRightClick.dispatchEvent(new MouseEvent('contextmenu', {
                        bubbles: true,
                        cancelable: true,
                        clientX: rect.left + (rect.width / 2),
                        clientY: rect.top + (rect.height / 2),
                        button: 2
                    }));

                    await sleep(400);

                    let menu = document.querySelector('[role="menu"]') || document.querySelector('[data-radix-menu-content]');
                    if (menu) {
                        menuOpened = true;
                        console.log("[Flow Downloader] Menu Radix berhasil muncul via Klik Kanan!");
                        break;
                    }

                    elementToRightClick = elementToRightClick.parentElement;
                    limit++;
                }
            }

            let menu = document.querySelector('[role="menu"]') || document.querySelector('[data-radix-menu-content]');
            if (!menuOpened || !menu) {
                console.error("[Flow Downloader] Gagal membuka menu opsi download.");
                resolve(false);
                return;
            }

            updateStatus("Memilih Resolusi...");
            let items = Array.from(menu.querySelectorAll('[role="menuitem"]'));
            let resOptions = resolutionText.split(',').map(s => s.trim());
            let targetItem = null;
            for (let res of resOptions) {
                targetItem = items.find(el => el.textContent.includes(res));
                if (targetItem) break;
            }

            // Jika opsi resolusi tidak langsung ditemukan di menu pertama
            if (!targetItem) {
                console.log(`[Flow Downloader] Resolusi ${resolutionText} tidak langsung ditemukan. Mencari tombol utama 'Download' / 'Unduh'...`);

                // Cari opsi "Download", "Unduh", "Save", atau "Simpan"
                let downloadTrigger = items.find(el => {
                    let txt = el.textContent.toLowerCase();
                    return txt.includes("download") || txt.includes("unduh") || txt.includes("save") || txt.includes("simpan");
                });

                if (downloadTrigger) {
                    console.log("[Flow Downloader] Menemukan tombol 'Download' utama. Mengklik...");
                    updateStatus("Membuka Opsi Resolusi...");

                    downloadTrigger.click();

                    await sleep(800); // Tunggu sub-menu / popper Radix muncul

                    // Cari ulang semua menu yang aktif di DOM
                    let activeMenus = Array.from(document.querySelectorAll('[role="menu"], [data-radix-menu-content]'));
                    console.log(`[Flow Downloader] Menemukan ${activeMenus.length} menu aktif setelah klik.`);

                    if (activeMenus.length <= 1) {
                        console.log("[Flow Downloader] Tidak ada submenu tambahan yang terbuka. Berarti tombol Download adalah pengunduh langsung (direct download)!");
                        showToast(`Lewati: Resolusi ${resolutionText} tidak tersedia pada gambar/media ini`, 'warning');
                        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
                        document.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, clientX: 0, clientY: 0 }));
                        document.body.click();
                        resolve(false);
                        return;
                    }

                    for (let activeMenu of activeMenus) {
                        let subItems = Array.from(activeMenu.querySelectorAll('[role="menuitem"]'));
                        // Pastikan kita mengecek sub-menu yang baru (bukan menu root yang sama)
                        if (subItems.length > 0 && !subItems.includes(downloadTrigger)) {
                            for (let res of resOptions) {
                                targetItem = subItems.find(el => el.textContent.includes(res));
                                if (targetItem) break;
                            }
                            if (targetItem) {
                                console.log(`[Flow Downloader] Berhasil menemukan opsi ${resolutionText} di sub-menu!`);
                            } else {
                                console.log(`[Flow Downloader] Resolusi ${resolutionText} tidak tersedia di sub-menu!`);
                            }
                            break;
                        }
                    }
                }
            }

            if (!targetItem) {
                console.warn(`[Flow Downloader] Melewati media. Opsi resolusi tidak ditemukan: ${resolutionText}`);
                showToast(`Lewati: Resolusi ${resolutionText} tidak ditemukan`, 'warning');
                document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
                document.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, clientX: 0, clientY: 0 }));
                document.body.click();
                resolve(false);
                return;
            }

            if (targetItem.getAttribute('aria-disabled') === 'true' || targetItem.hasAttribute('data-disabled')) {
                console.warn("[Flow Downloader] Opsi resolusi dinonaktifkan:", resolutionText);
                document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
                document.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, clientX: 0, clientY: 0 }));
                document.body.click();
                resolve(false);
                return;
            }

            console.log(`[Flow Downloader] Mengklik opsi resolusi: ${resolutionText}`);
            updateStatus("Memicu Unduhan...");

            // 1. Masukkan ID media ini ke dalam Antrean Verifikasi Latar Belakang
            pendingVerificationQueue.push(tileId);

            // 2. Set Timer Timeout 20 detik secara asinkron (tidak memblokir!)
            // Jika dalam 20 detik Chrome belum memberikan sinyal unduhan, anggap Gagal!
            setTimeout(() => {
                let index = pendingVerificationQueue.indexOf(tileId);
                if (index !== -1) {
                    // Masih ada di antrean setelah 20 detik? Berarti gagal diunduh!
                    pendingVerificationQueue.splice(index, 1);
                    console.warn(`[Flow Downloader] ❌ Latar Belakang: Unduhan ${tileId} dibatalkan karena timeout 20 detik (Sangat mungkin Kuota Habis/Error).`);
                    showToast(`Gagal: Kuota Limit / Error Server`, 'error');
                }
            }, 20000);

            // 3. Klik opsi menu tersebut
            targetItem.click();

            // 4. Langsung Lanjut! (Beri jeda super singkat agar UI menu Radix menutup dengan mulus)
            await sleep(600);
            resolve(true); 
        });
    }

})();
