document.addEventListener('DOMContentLoaded', () => {
    const startBtn = document.getElementById('fad-start');
    const stopBtn = document.getElementById('fad-stop');
    const clearBtn = document.getElementById('fad-clear');
    const statusEl = document.getElementById('fad-status');
    const resSelect = document.getElementById('fad-resolution');
    const videoResSelect = document.getElementById('fad-video-resolution');
    const folderInput = document.getElementById('fad-folder');
    const delayInput = document.getElementById('fad-delay');
    const skipDownloadedCheckbox = document.getElementById('fad-skip-downloaded');

    function updateUI(isDownloading, statusText) {
        if (isDownloading) {
            startBtn.style.display = 'none';
            stopBtn.style.display = 'block';
            resSelect.disabled = true;
            videoResSelect.disabled = true;
            folderInput.disabled = true;
            delayInput.disabled = true;
            skipDownloadedCheckbox.disabled = true;
        } else {
            startBtn.style.display = 'block';
            stopBtn.style.display = 'none';
            resSelect.disabled = false;
            videoResSelect.disabled = false;
            folderInput.disabled = false;
            delayInput.disabled = false;
            skipDownloadedCheckbox.disabled = false;
        }
        
        const statusTextEl = document.getElementById('status-text');
        if (statusTextEl) {
            statusTextEl.textContent = 'Status: ' + statusText;
            const statusDot = document.getElementById('status-dot');
            if (statusDot) {
                if (isDownloading) statusDot.classList.add('active');
                else statusDot.classList.remove('active');
            }
        } else {
            statusEl.textContent = 'Status: ' + statusText;
        }
    }

    // Muat konfigurasi tersimpan
    chrome.storage.local.get(['fad_folder', 'fad_skip_downloaded', 'fad_delay'], (res) => {
        if (res.fad_folder) {
            folderInput.value = res.fad_folder;
        }
        if (res.fad_skip_downloaded !== undefined) {
            skipDownloadedCheckbox.checked = res.fad_skip_downloaded;
        }
        if (res.fad_delay !== undefined) {
            delayInput.value = res.fad_delay;
        }
    });

    // Cek seluruh tab untuk logic Switch Tab / Open Tab
    chrome.tabs.query({}, (allTabs) => {
        chrome.tabs.query({active: true, currentWindow: true}, (activeTabs) => {
            if (activeTabs.length > 0) {
                let currentTab = activeTabs[0];
                
                // Jika tab aktif saat ini BUKAN Google Labs Flow
                if (!currentTab.url || !(currentTab.url.includes("labs.google/fx") && currentTab.url.includes("tools/flow"))) {
                    // Cari apakah sudah ada tab Flow yang terbuka di background/window lain
                    let existingFlowTab = allTabs.find(t => t.url && t.url.includes("labs.google/fx") && t.url.includes("tools/flow"));
                    
                    if (existingFlowTab) {
                        // Jika ada, langsung pindah (switch) ke tab tersebut!
                        chrome.tabs.update(existingFlowTab.id, { active: true });
                        chrome.windows.update(existingFlowTab.windowId, { focused: true });
                    } else {
                        // Jika tidak ada sama sekali, baru buka tab baru
                        chrome.tabs.create({ url: "https://labs.google/fx/tools/flow" });
                    }
                    return; // Pop-up akan otomatis tertutup saat berpindah tab
                }

                // Jika sudah berada di Google Labs Flow, pastikan ini halaman PROJECT
                if (!currentTab.url.includes("/project/")) {
                    const startBtn = document.getElementById('fad-start');
                    startBtn.disabled = true;
                    startBtn.style.opacity = "0.5";
                    startBtn.style.cursor = "not-allowed";
                    updateUI(false, "Buka salah satu project terlebih dahulu.");
                    return; // Jangan tanya content script karena belum di dalam project
                }

                // Jika benar di halaman project, tanya status ke content script
                chrome.tabs.sendMessage(currentTab.id, { action: "get_status" })
                    .then((response) => {
                        if (response) {
                            updateUI(response.isDownloading, response.statusText);
                        }
                    })
                    .catch((err) => {
                        updateUI(false, "Sedang memuat Project Flow...");
                    });
            }
        });
    });

    // Terima update status real-time dari content script
    chrome.runtime.onMessage.addListener((msg) => {
        if (msg.action === "update_status") {
            updateUI(msg.isDownloading, msg.statusText);
        }
    });

    startBtn.addEventListener('click', () => {
        // Simpan konfigurasi ke storage
        chrome.storage.local.set({
            fad_folder: folderInput.value,
            fad_skip_downloaded: skipDownloadedCheckbox.checked,
            fad_delay: delayInput.value
        });

        chrome.runtime.sendMessage({ action: "set_folder", folder: folderInput.value }).catch(()=>{});
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            if (tabs.length > 0) {
                chrome.tabs.sendMessage(tabs[0].id, { 
                    action: "start_download",
                    resolution: resSelect.value + "," + videoResSelect.value,
                    skipDownloaded: skipDownloadedCheckbox.checked,
                    batchDelay: parseFloat(delayInput.value) || 3
                }).catch(()=>{});
            }
        });
        updateUI(true, "Memulai...");
    });

    stopBtn.addEventListener('click', () => {
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            if (tabs.length > 0) {
                chrome.tabs.sendMessage(tabs[0].id, { action: "stop_download" }).catch(()=>{});
            }
        });
        updateUI(false, "Berhenti.");
    });

    clearBtn.addEventListener('click', () => {
        if (confirm('Yakin ingin menghapus history download? Semua gambar akan didownload ulang jika dipilih lagi.')) {
            chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
                if (tabs.length > 0) {
                    chrome.tabs.sendMessage(tabs[0].id, { action: "clear_history" }).catch(()=>{});
                }
            });
            alert('History dihapus!');
        }
    });
});
