let currentFolderName = "Flow_Downloads";

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "set_folder") {
        currentFolderName = request.folder;
        sendResponse({ success: true });
    }
});

chrome.downloads.onCreated.addListener((downloadItem) => {
    // Beri tahu semua tab bahwa download sudah dimulai
    chrome.tabs.query({}, function (tabs) {
        for (let tab of tabs) {
            chrome.tabs.sendMessage(tab.id, { action: "download_started", item: downloadItem }).catch(() => { });
        }
    });
});

chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
    if (currentFolderName && currentFolderName.trim() !== "") {
        let folder = currentFolderName.trim();
        // Hapus karakter slash di awal/akhir jika ada agar rapi
        folder = folder.replace(/^[\/\\]+|[\/\\]+$/g, '');
        suggest({ filename: folder + "/" + item.filename });
    } else {
        suggest({ filename: item.filename });
    }
});
